<?php
require $_SERVER["DOCUMENT_ROOT"] . '/connectdb.php';
include $_SERVER["DOCUMENT_ROOT"] . '/class/betflix.php';
include $_SERVER["DOCUMENT_ROOT"] . '/class/scb.php';
session_start();

echo '<pre>';
print_r($_SESSION);
print_r($_POST);

if(isset($_SESSION['name_ad'])){

}