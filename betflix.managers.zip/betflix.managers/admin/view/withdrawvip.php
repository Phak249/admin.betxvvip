<?php include '../inc/header.php'; ?>
<?php include '../Command/body_deposit_vip.php'; ?>
<?php include '../inc/footer.php'; ?>