<?php
 ///require '../config/config.php';
// error_reporting(0);


class Changpass
{

    public function Curl($method, $url, $header, $data, $cookie)
	{
		// $proxy_login = $this->proxy;
		// $proxy_auth = $this->proxyauth;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36');
		// curl_setopt($ch, CURLOPT_PROXY, $proxy_login);
		// curl_setopt($ch, CURLOPT_PROXYUSERPWD,  $proxy_auth);
		curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS4);  
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
		curl_setopt($ch, CURLOPT_TIMEOUT, 9);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		if ($data) {
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if ($cookie) {
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		return curl_exec($ch);
	}
    
    
    public function DOMXPath($html, $qry)
    {
        $doc = new DOMDocument();
        @$doc->loadHTML($html);
        $xpath = new DOMXPath($doc);
        $nodeList = $xpath->query($qry);
        
        return $nodeList;
    }
    
    function getCookie()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://www.usa2468.com/Default8.aspx?lang=EN-GB");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($ch, CURLOPT_PROXY, $proxy);
        // curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
        //curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS4);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "cache-control: no-cache",
            "sec-fetch-dest: document",
            "sec-fetch-mode: navigate",
            "sec-fetch-site: none",
            "sec-fetch-user: ?1",
            "upgrade-insecure-requests: 1",
            "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36"
        ));
        $result = curl_exec($ch) or die(curl_error($ch));
        curl_close($ch);
        
        preg_match('/(?<=__cflb).(.*?)(?=\;)/', $result, $__cflb);
        preg_match('/(?<=NET_SessionId).(.*?)(?=\;)/', $result, $NET_SessionId);
        preg_match('/(?<=__cf_bm).(.*?)(?=\;)/', $result, $__cf_bm);
        
        $Cookie = "Cookie: __cflb" . trim($__cflb[0]) . ";ASP.NET_SessionId" . trim($NET_SessionId[0]) . ";__cf_bm" . trim($__cf_bm[0]);
        return $Cookie;
    }
    
    function code($cookie)
    {
        $url = "https://www.usa2468.com/Default8.aspx?lang=EN-GB";
        $header = array(
            "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "cache-control: no-cache",
            "sec-fetch-dest: document",
            "sec-fetch-mode: navigate",
            "sec-fetch-site: none",
            "sec-fetch-user: ?1",
            "upgrade-insecure-requests: 1",
            "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36"
        );
        $res = $this->Curl('GET', $url, $header, false, $cookie);
        $__VIEWSTATE = $this->DOMXPath($res, "//input[@name='__VIEWSTATE']/@value");
        $__VIEWSTATEGENERATOR = $this->DOMXPath($res, "//input[@name='__VIEWSTATEGENERATOR']/@value");
        $key = $__VIEWSTATE[0]->nodeValue;
        $key1 = $__VIEWSTATEGENERATOR[0]->nodeValue;
        return ['key' => urlencode($key) , 'key1' => $key1];
    }

    function login($code, $cookie, $user, $pass)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://www.usa2468.com/Default8.aspx?lang=EN-GB");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "__EVENTARGUMENT=&__EVENTTARGET=btnLogin&__VIEWSTATE=" . $code['key'] . "&__VIEWSTATEGENERATOR=" . $code['key1'] . "&lstLang=Default8.aspx?lang=EN-GB&password=" . $pass . "&txtUserName=" . $user);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "cache-control: no-cache",
            "sec-fetch-dest: document",
            "sec-fetch-mode: navigate",
            "sec-fetch-site: none",
            "sec-fetch-user: ?1",
            "upgrade-insecure-requests: 1",
            $cookie,
            "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36"
        ));
        return curl_exec($ch) or die(curl_error($ch));
    }

    function getcode($cookie)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.usa2468.com/Public/ChgPwd2.aspx?lang=EN-GB');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
        // curl_setopt($ch, CURLOPT_PROXY, $proxy);
        // curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
        $headers = array();
        $headers[] = 'Authority: www.ts911abc.info';
        $headers[] = 'Cache-Control: max-age=0';
        $headers[] = 'Upgrade-Insecure-Requests: 1';
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36';
        $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
        $headers[] = 'Sec-Fetch-Site: same-origin';
        $headers[] = 'Sec-Fetch-Mode: navigate';
        $headers[] = 'Sec-Fetch-User: ?1';
        $headers[] = 'Sec-Fetch-Dest: document';
        $headers[] = 'Referer: https://www.boss369.com/Default8.aspx?lang=EN-GB';
        $headers[] = 'Accept-Language: en-US,en;q=0.9';
        $headers[] = $cookie;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        echo $result;
        if (curl_errno($ch))
        {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        preg_match_all('/(?<=VIEWSTATE\" value\=\").(.*?)(?=\")/', $result, $output_array);
        $__VIEWSTATE = urlencode($output_array[0][0]);
        preg_match_all('/(?<=VIEWSTATEGENERATOR\" value\=\").(.*?)(?=\")/', $result, $output_array);
        $__VIEWSTATEGENERATOR = urlencode($output_array[0][0]);
        preg_match_all('/(?<=__EVENTVALIDATION\" value\=\").(.*?)(?=\")/', $result, $output_array);
        $__EVENTVALIDATION = urlencode($output_array[0][0]);

        return ['viewstate' => $__VIEWSTATE, 'viewstategen' => $__VIEWSTATEGENERATOR, 'eventval' => $__EVENTVALIDATION];
    }

    function changepass($cookie, $code, $oldpass, $newpass)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.usa2468.com/Public/ChgPwd2.aspx?lang=EN-GB');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        // curl_setopt($ch, CURLOPT_PROXY, $proxy);
        // curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=" . $code["viewstate"] . "&__VIEWSTATEGENERATOR=" . $code["viewstategen"] . "&__EVENTVALIDATION=" . $code['eventval'] . "&txtOldPassword=" . $oldpass . "&txtNewPassword=" . urlencode($newpass) . "&txtConfirmPassword=" . urlencode($newpass) . "&btnSave=%E0%B8%A2%E0%B8%B7%E0%B8%99%E0%B8%A2%E0%B8%B1%E0%B8%99");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "cache-control: no-cache",
            "sec-fetch-dest: document",
            "sec-fetch-mode: navigate",
            "sec-fetch-site: none",
            "sec-fetch-user: ?1",
            "upgrade-insecure-requests: 1",
            $cookie,
            "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36"
        ));
        return curl_exec($ch) or die(curl_error($ch));
    }

    function chang($user, $pass, $newpass)
    {
        $cookie = $this->getCookie();
        $key = $this->code($cookie);
        $this->login($key, $cookie, $user, $pass);
        $codeforchangepassword = $this->getcode($cookie);
        $this->changepass($cookie, $codeforchangepassword, $pass, $newpass);
    }

    function ranza(){return mt_rand(10000000, 99999999);}

    public function Ekkapon($user, $pass)
    {
     
        $newpass = "Aa112233";
        $this->chang($user, $pass, $newpass);
        //echo "\nuser: ".$user." newpass: ".$newpass;
    }
}
