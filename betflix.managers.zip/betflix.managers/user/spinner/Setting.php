<?php

$S_Host = "localhost";
$S_User = "root";
$S_Password = "";
$S_Database = "storage_betxv1";
$S_Table_Accounts = "member";
$S_Table_Setting = "setting";
$S_Table_History = "history_spin";
$S_Credit_Column = "creditspin";
$S_Reward_Column = "point";
$S_CreditToPlay = "1";
$S_Text_Reward = "&#1072;&#1105;&#1115;&#1072;&#8470;�&#1072;&#1105;�&#1072;&#1105;&#1118;&#1072;&#1105;�&#1072;&#8470;&#1034;";

$S_SESSION_Username = $_SESSION["username_mb"];
$S_SESSION_ID = $_SESSION["id_mb"];

$LICENSE = "darkcreaterweb";
?>