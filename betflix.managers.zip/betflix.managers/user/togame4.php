
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="ljo8EGWMIfq5QkMRHEYa5P4LKT6Ky1yJoTp9OViZ">
<title>Redirect page to...</title>
<link rel="shortcut icon" href="favicon.html">

<link href="https://fonts.googleapis.com/css?family=Prompt:400,700&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/appa26e.html?id=03ba0a0679e98ea733fb">
<script src="../ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
<p class="p-2 text-center">loading to game <a class="link-support" href="https://time899.com/HomeSmart.aspx?lang=EN-GB"></a> after <span id="countdown">10</span> seconds</p>
<form method="post" action="#" id="form1" style="display: none;">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTIwODA5MzEwNjIPZBYCZg9kFgQCBA8WAh4LcGxhY2Vob2xkZXIFHuC4iuC4t+C5iOC4reC4nOC4ueC5ieC5g+C4iuC5iWQCBQ8WAh8ABRjguKPguKvguLHguKrguJzguYjguLLguJlkZJaFEiFjuC1LZtis499ecRv5g/Ct" />


	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="DF40E925" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAATZ1uXbStNbg+HPHOXCmZrpY3plgk0YBAefRz3MyBlTcO4sciJO3Hoc68xTFtZGQEivn9vBjVd9fs+uQ2w6sTEuRTY/TGAwzmXGSVNwTFhs8380tRw=" />

<input type="text" name="lstLang" value="HomeSmart.aspx?lang=EN-GB">
<input name="txtUserName" type="text" id="txtUserName" maxlength="16" value="" />
<input name="password" type="text" id="txtPassword" maxlength="16" value="Aa123456" />
</form>
<script type="text/javascript">
		//<![CDATA[
		var theForm = document.forms['form1'];
		if (!theForm) {
		    theForm = document.form1;
		}
		function __doPostBack(eventTarget, eventArgument) {
		    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
		    	theForm.action =  'https://www.time899.com/HomeSmart.aspx?lang=EN-GB';
		        theForm.__EVENTTARGET.value = eventTarget;
		        theForm.__EVENTARGUMENT.value = eventArgument;
		        theForm.submit();
		    }
		}
		//setTimeout(function(){ __doPostBack('btnLogin','') }, 5000);
	    var seconds = 3;
	    function countdown() {
	        seconds = seconds - 1;
	        if (seconds < 0) {
	            __doPostBack('btnSignIn','','https://www.time899.com/')
	        } else {
	            document.getElementById('countdown').innerHTML = seconds;
	            window.setTimeout('countdown()', 300);
	        }
	    }
	    countdown();
	    //]]>
	</script>
</body>

