<head>
  <meta http-equiv="refresh" content="30">
</head>
<?php
require '../config.php';
error_reporting(0);
header("Content-Type: text/html; charset=utf-8");
$sql = "SELECT * FROM bank WHERE name_bank='ธนาคารกสิกรไทย'";
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);




$sql = "SELECT * FROM setting";
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);
$status_transfer=$row['status_auto'];
$limit_scb = $row['max_autowd'];
$status_auto2 = $row['status_auto2'];

if ($status_auto2=='เปิด') {
	echo 'ระบบถอนเปิดอยู่';
if($status_transfer!='เปิด'){
	echo 'ฟังชั่นปิดอยู่';
exit();
}



//หากลูกค้ารับโปรวันนี้ จะไม่สามารถถอนออโต้ได้
$sql = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND bank_wd!="ธนาคารกสิกรไทย" ORDER by id asc LIMIT 1';
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);
$phone2 = $row['phone_wd'];
//echo $phone;

$today_pro = date('Y-m-d');
$sql2 = "SELECT * FROM deposit WHERE phone_dp = $phone2 AND date_dp LIKE '%$today_pro%' AND promotion_dp!='ไม่รับโบนัส' AND confirm_dp='อนุมัติ'";
$query2 = $server->query($sql2);
$row55 = mysqli_fetch_assoc($query2);
$check2 = $query2->num_rows;
$phonepro = $row55['phone_dp'];
$propro = $row55['promotion_dp'];
echo $check2;

if ($check2>0) {
	echo 'ลูกค้ารับโปรก่อนหน้านี้';
	$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
					$result5 = $server->query($sql5);
					$row5 = mysqli_fetch_assoc($result5);
					$key = $row5['linewithdraw'];
										$sMessage = "มีรายการถอนค้างอยู่ \nเบอร์ ".$phonepro." \nลูกค้ารับโปรโมชั่น \nกรุณาตรวจสอบ \nโปรโมชั่นที่รับ : ".$propro;
								
										$chOne = curl_init(); 
										curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
										curl_setopt( $chOne, CURLOPT_POST, 1); 
										curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
										$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
										curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
										$result = curl_exec( $chOne ); 
										if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
											$result_ = json_decode($result, true); } 
											curl_close( $chOne );
exit();
}else{


$withdraw = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND bank_wd!="ธนาคารกสิกรไทย" AND lastpro="ไม่รับโบนัส" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1';//ถ้าไม่ต้องการเช็คคนที่รับโปร ก่อนถอน เอา lastpro="ไม่รับโบนัส" ออก

$result = $server->query($withdraw);
$withdraw=array();
foreach ($result as $row) {


	
	$sql1 = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1';
	$result1 = $server->query($sql1);
	$row1 = mysqli_fetch_assoc($result1);

	$row['bank_name1']=$row1['bank_wd'];
	$row['bank_number']=$row1['bankacc_wd'];

//echo $row['bank_name1'];

	array_push($withdraw,$row);


}

 
?>


<?php $i=1; foreach ($withdraw as $key => $value) {
     $credit=$value['amount_wd'];
	// echo $limit_scb;
	// echo '<br>';
	//  echo $credit;
	// echo '<br>';
	// echo $limit_scb;
	 if ($credit<=$limit_scb){
	 		
	 		
		 $phone=$value ['phone_wd'];
			echo 'ถอนได้';
		
			$sql55 = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1';
			$result55 = $server->query($sql55);
			$row55 = mysqli_fetch_assoc($result55);
			$pin_wd = $row55['pin_wd'];
//echo $pin_wd;
			if ($pin_wd=='unknown6134') {
			
			//echo $endpoint;

require'../kbank525698/kplus.Class.php';
 $api = new Kplus($endpoint);


//echo $row['bank_name1'];

	function code($value){
  $value=trim($value);

  if ($value=="ธ.ไทยพาณิชย์") {
    return '010';
  }

  if ($value=="ธ.กรุงเทพ") {
    return '003';
  }

  if ($value=="ธ.กสิกรไทย") {
    return '001';
  }

  if ($value=="ธ.กรุงไทย") {
    return '004';
  }

  if ($value=="ธ.ทหารไทยธนชาติ") {
    return '007';
  }

  if ($value=="ธ.กรุงศรีอยุธยา") {
    return '017';
  }
  if ($value=="ธ.ออมสิน") {
    return '022';
  }

  if ($value=="ธ.ก.ส.") {
    return '026';
  }
  
  if ($value=="ธ.ซีไอเอ็มบีไทย") {
    return '018';
  }
  
  if ($value=="ธ.เกียรตินาคิณภัทร") {
    return '023';
  }
  
  if ($value=="ธ.ทิสโก้") {
    return '029';
  }
  
  if ($value=="ธ.ยูโอบี") {
    return '016';
  }
  
  if ($value=="ธ.อิสลาม") {
    return '028';
  }
  
  if ($value=="ธ.ไอซีบีซี") {
    return '030';
  }

}
			$accountTo=$value['bank_number'];
			$accountToBankCode=code($value['bank_name1']);  
			$amount=$credit;
			echo $accountToBankCode;
			echo $credit;
		
			
	$data = json_encode($api->transferVerify($accountToBankCode, $accountTo, $amount));

$wd=json_decode($data);
$code_wd5=$wd->kbankInternalSessionId;
$code_wd=$wd->error;
//echo $code_wd5;
if ($code_wd == 'NF-CIGW21, เลขที่บัญชีปลายทางไม่ถูกต้อง กรุณาตรวจสอบและทำรายการใหม่อีกครั้ง') {
  
  echo "เลขที่บัญชีปลายทางไม่ถูกต้อง";
  
}else{
  $data2 = json_encode($api->transferConfrim($code_wd5));
  $qrcode2 = json_decode($data2);
  $qrcode=$qrcode2->rawQr;

  
  
}

			$sql4 = 'SELECT * FROM bank WHERE name_bank="ธนาคารกสิกรไทย" AND status_bank="เปิด"';
				$result4 = $server->query($sql4);
				$row4 = mysqli_fetch_assoc($result4);

				$bankout_no=$row4['bankacc_bank'];


			
			
			if ($qrcode!='') {
									
				$sql = "UPDATE withdraw SET  
            					confirm_wd='อนุมัติ' , 
            					pin_wd='',
            					edit_wd='AUTO' ,
            					bankout_wd='ธนาคารกสิกรไทย $bankout_no' 
            					WHERE phone_wd='$phone' AND confirm_wd='รอดำเนินการ'";

			if ($server->query($sql) === TRUE) {
			
			$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
			$result5 = $server->query($sql5);
			$row5 = mysqli_fetch_assoc($result5);
			$key = $row5['linewithdraw'];

			$sMessage = "BOT อนุมัติถอน \nจำนวนเงิน ".$amount." บาท\nเบอร์ ".$phone;
			$chOne = curl_init(); 
				curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				curl_setopt( $chOne, CURLOPT_POST, 1); 
				curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				$result = curl_exec( $chOne ); 
				if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
					$result_ = json_decode($result, true); } 
					curl_close( $chOne );
									
									
					$data = array ('msg'=>"ทำรายการ สำเร็จ!",'status'=>200);
					echo json_encode($data);
					exit();
				
										
				$data = array ('msg'=>'success!','phone'=>$GLOBALS["phone"],'id'=>$GLOBALS["id"],'status'=>200);
					echo json_encode($data);
					exit();
								  
				}else{
										  
					$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
					$result5 = $server->query($sql5);
					$row5 = mysqli_fetch_assoc($result5);
					$key = $row5['linewithdraw'];

					$sMessage = "BOT! ธนาคารถอนมีปัญหา \nจำนวนเงิน ".$value['credit']." บาท\nเบอร์ ".$value['phone'];
					$chOne = curl_init(); 
					curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
					curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
					curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
					curl_setopt( $chOne, CURLOPT_POST, 1); 
					curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
					$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
					curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
					curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
					$result = curl_exec( $chOne ); 
						if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
							$result_ = json_decode($result, true); } 
							curl_close( $chOne );
									
							$data = array ('msg'=>$status,'status'=>500);
								echo json_encode($data);
								exit();
							}	
					 


		 
	 }else{
					$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
					$result5 = $server->query($sql5);
					$row5 = mysqli_fetch_assoc($result5);
					$key = $row5['linewithdraw'];

										$sMessage = "BOT! มีรายการถอนค้างอยู่ \nจำนวนเงิน ".$value['credit']." บาท\nเบอร์ ".$value['phone'];
										$chOne = curl_init(); 
										curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
										curl_setopt( $chOne, CURLOPT_POST, 1); 
										curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
										$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
										curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
										$result = curl_exec( $chOne ); 
										if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
											$result_ = json_decode($result, true); } 
											curl_close( $chOne );
				
					$data = array ('msg'=>$status,'status'=>500);
					echo json_encode($data);
					
		 // echo 'เกินงบ ถอนไม่ได้';
	 }
}
}else{
	echo 'ยอดถอนเกินที่ตั้งไว้';
	}
	?>
 

<?php $i++; } 
}
}else{ echo 'ระบบออโต้ปิด';}


 ?>
