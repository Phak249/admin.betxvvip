<?php include '../inc/header.php'; ?>
<?php include '../Command/body_member.php'; ?>
<?php include '../inc/footer.php'; ?>