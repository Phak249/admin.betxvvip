
<?php
 error_reporting(0);
require '../connectdb.php';
$sql = "SELECT * FROM setting";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);



// $agent_user=$row['agent'];
// $GLOBALS["api_betflix"]=$row['pass_agent'];
// $GLOBALS["apikey"]=$row['txtTotal'];
// echo $agent_user;


$sql="SELECT * FROM member WHERE phone_mb =''" or die("Error:" . mysqli_error());
$result = mysqli_query($con, $sql);
$num=mysqli_num_rows($result);

function generateRandomString($length = 5) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

$username=generateRandomString();

if ($num<30) {

$username=generateRandomString(); 
$password=urlencode('aa123456');

require 'api_betflix2.php';


$register = register($username,$password);
$register2=json_decode($register);
$status=$register2->status;
if ($status=='success') {
	

$sql = "INSERT INTO member (username_mb, password_ufa,status)
       VALUES('$username', '$password',2)";
	   echo $sql;
	if (mysqli_query($con, $sql) === TRUE) {


			echo"successfully";

 exit();
}else{
	echo"no no no";
}				
  }else{
  	echo"can not register";
  }




  

}else{

	echo 'สต็อกยูสเซอร์เต็มแล้ว';
}


?>
