<?php
session_start();
if(!isset($_SESSION['id_ad'])){
 echo "no no no";
 exit;

}else{
require '../config.php';
$sql = "SELECT * FROM bank WHERE name_bank='ธนาคารกสิกรไทย'";
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);

require_once __DIR__ . '/kplus.Class.php';
 	header("Content-Type: text/html; charset=utf-8");


$api = new Kplus($endpoint);

// $json = json_encode($api->getTransactions());

// $json = json_encode($api->getTransactionDetail('001_20220409_0146971702D563DEA6C,A,CR,N'));
// echo( $json);
function code($value)
{
  $value=trim($value);

  if ($value=="ธ.ไทยพาณิชย์") {
    return '010';
  }

  if ($value=="ธ.กรุงเทพ") {
    return '003';
  }

  if ($value=="ธ.กสิกรไทย") {
    return '001';
  }

  if ($value=="ธ.กรุงไทย") {
    return '004';
  }

  if ($value=="ธ.ทหารไทยธนชาติ") {
    return '007';
  }

  if ($value=="ธ.กรุงศรีอยุธยา") {
    return '017';
  }
  if ($value=="ธ.ออมสิน") {
    return '022';
  }

  if ($value=="ธ.ก.ส.") {
    return '026';
  }
  
  if ($value=="ธ.ซีไอเอ็มบี") {
    return '018';
  }
  
  if ($value=="ธ.เกียรตินาคินภัทร") {
    return '023';
  }
  
  if ($value=="ธ.ทิสโก้") {
    return '029';
  }
  
  if ($value=="ธ.ยูโอบี") {
    return '016';
  }
  
  if ($value=="ธ.อิสลาม") {
    return '028';
  }
  
  if ($value=="ธ.ไอซีบีซี") {
    return '030';
  }

}


$accountTo=$_POST['accountTo'];
$namebank=$_POST['accountToBankCode'];
$accountToBankCode=code($_POST['accountToBankCode']);
$amount=$_POST['amount']; 
$key_input=$_POST['key_input'];
$add_wd=$_POST['add_wd'];
//echo $amount;

if ($key_input=='123123' AND $add_wd!='') {

print_r($api->transferVerify($accountToBankCode, $accountTo, $amount));
$data = json_encode($api->transferVerify($accountToBankCode, $accountTo, $amount));

$wd=json_decode($data);
$code_wd5=$wd->kbankInternalSessionId;
$code_wd=$wd->error;
echo $code_wd5;
if ($code_wd == 'NF-CIGW21, เลขที่บัญชีปลายทางไม่ถูกต้อง กรุณาตรวจสอบและทำรายการใหม่อีกครั้ง') {
  echo "<script type='text/javascript'>";
  echo "alert('เลขที่บัญชีปลายทางไม่ถูกต้อง');";
  echo "window.location.href='javascript:history.back(1)'; ";
  echo "</script>";
}else{

  //echo 7777;
  $data2 = json_encode($api->transferConfrim($code_wd5));
  $qrcode2 = json_decode($data2);
  $qrcode=$qrcode2->rawQr;
//echo $qrcode;
  if ($qrcode!='') {
  
  require '../connectdb.php';
  $sql3 = "SELECT * FROM setting";
  $result3 = mysqli_query($con, $sql3);
  $row3 = mysqli_fetch_assoc($result3);
  $key = $row3['linewithdraw'];

      $sMessage = "โอนเงินออก KBank \nจำนวนเงิน ".$amount." บาท \nเข้า ".$namebank." \nเลขบัญชี ".$accountTo." \nผู้ทำรายการ ".$add_wd;
      $chOne = curl_init(); 
        curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
        curl_setopt( $chOne, CURLOPT_POST, 1); 
        curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
        $headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
        curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
        curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
        $result = curl_exec( $chOne ); 
        if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
          $result_ = json_decode($result, true); } 
          curl_close( $chOne );

   echo "<script type='text/javascript'>";
  echo "alert('โอนเงินสำเร็จ');";
  echo "window.location.href='javascript:history.back(1)'; ";
  echo "</script>";
  }else{
    echo "<script type='text/javascript'>";
  echo "alert('โอนเงินผิดพลาด');";
 echo "window.location.href='javascript:history.back(1)'; ";
  echo "</script>";
  }
  
}





}else{
    echo "<script type='text/javascript'>";
  echo "alert('รหัสโอนเงินไม่ถูกต้อง');";
  echo "window.location.href='javascript:history.back(1)'; ";
  echo "</script>";
  }
}