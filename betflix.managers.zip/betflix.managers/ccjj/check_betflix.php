<?php
require '../connectdb.php';
include '../class/betflix.php';
$api = new Betflix();


//checkcredit agent
$agent_info = $api->agentinfo();
if (!$agent_info->error_code) {
	$credit = $agent_info->data->total_credit;
	print_r($agent_info);
	$sql = "UPDATE credit SET credit_ufa = '$credit' WHERE id = 1";
	$result = mysqli_query($con, $sql) or die("Error in query: $sql ");
}else{
	exit(json_encode($agent_info));
}
