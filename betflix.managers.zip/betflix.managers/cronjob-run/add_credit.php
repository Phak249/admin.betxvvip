<head>
  <meta http-equiv="refresh" content="10">
</head>
<?php
 //error_reporting(0);

require '../config/connectdb.php';
require 'apiufa1062.php';

$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$agent_user=$row['agent'];
$key = $row['linedeposit'];
$path='https://'.$row['link_web']."/";
$status_auto2 = $row['status_auto2'];
//echo $path;
if ($status_auto2=='เปิด') {
	

$sql_scb = "SELECT * FROM bank WHERE name_bank='ธนาคารไทยพาณิชย์' ORDER BY id DESC LIMIT 1";
$result_scb = mysqli_query($con, $sql_scb);
$row_scb = mysqli_fetch_assoc($result_scb);
$status_scb=$row_scb['status_bank'];
//echo $status_scb;

echo "scb ".$status_scb;
print"\n";
print"<br>";
date_default_timezone_set("Asia/Bangkok");
$date_now=date("Y-m-d");


 
$curl = curl_init();
curl_setopt_array($curl, array(
	CURLOPT_URL =>  $path."cronjob-run/api_scb.php?transactions",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
));

$transactions = curl_exec($curl);
curl_close($curl);
 
$result_transactions = json_decode($transactions,true);
 
$transactions_result=$result_transactions['result'];

//echo $transactions_result;

$curl = curl_init();
curl_setopt_array($curl, array(
	CURLOPT_URL => $path."cronjob-run/api_scb.php?balance",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
));

$balance = curl_exec($curl);
curl_close($curl);


	if ($status_scb=='เปิด') {
		

	foreach ($transactions_result as  $value) {
$txnCode=$value['txnCode']['description']; //รายการ
$txnDateTime=$value['txnDateTime']; //เวลา
$deposit=$value['txnAmount']; //ยอดเงิน
$txnRemark=$value['txnRemark']; //เลขบัญชี
$name=$value['txnRemark']; //ชื่อ
//echo $txnCode;
//echo $deposit;

preg_match('/SCB/', $txnRemark, $output_array);
$check=$output_array[0];
$check_bank=$output_array[0];
if ($check=="SCB") {
	preg_match_all('/(?<=x)(.*?)(?= )/', $txnRemark, $output_array);
	$fromAccount=$output_array[0][0];
	$naem_cut=explode(" ",$name);
	$name='ไทยพาณิชย์';
	$namescb=$naem_cut[4];


}else{
	preg_match_all('/(?<=X).+/', $txnRemark, $output_array);
	$fromAccount=$output_array[0][0];
	preg_match('/.(.*?)(?= )/', $name, $output_array);
	$name=$output_array[0];


}
//echo $deposit;


preg_match('/(.*?)(?=T)/', $txnDateTime, $output_array);
$date=date_create($output_array[0]);
$date_check=date_format($date,"Y-m-d");

preg_match('/(?<=T).(.*?)(?=\+)/', $txnDateTime, $output_array);
$time_check=$output_array[0];
//echo $time_check;
//echo $fromAccount;
if ($txnCode=="ฝากเงิน") {

	$sql_checkdp = "SELECT * FROM deposit WHERE date_check='$date_check' AND time_check='$time_check' AND fromAccount = '$fromAccount'";
	$query2 = mysqli_query($con, $sql_checkdp);
	$check2 = $query2->num_rows;
//echo $check2;
	if ($check2==0) {
		
	
	$sql_check = "SELECT * FROM deposit WHERE bankacc_dp LIKE '%$fromAccount%' AND confirm_dp='รอดำเนินการ' ORDER BY id DESC LIMIT 1"; 

	$query = mysqli_query($con, $sql_check);

	$row_pro = mysqli_fetch_assoc($query);
	$get_pro = $row_pro['promotion_dp'];
	$username = $row_pro['username_dp'];
	$phone_dp = $row_pro['phone_dp'];
	$check = $query->num_rows;
//echo $get_pro;
	if ($check==1) {
		$sql_promotion="SELECT * FROM promotion WHERE name_pro='$get_pro'";
		$result7 = mysqli_query($con, $sql_promotion);
		$row7 = mysqli_fetch_assoc($result7);
		$money = $row7['dp_pro'];
		$namepro= $row7['name_pro'];
		$bonusper_pro = $row7['bonusper_pro'];
		$dp_pro = $row7['dp_pro'];
		$turn = $row7['turn_pro'];

function extract_int($str){
     preg_match('/[^0-9]*([0-9]+)[^0-9]*/', $str, $regs);
     return (intval($regs[1]));
}
$a=$turn;
$turnover1 = extract_int($a);

		$bonus_pro = $row7['bonus_pro'] + ($deposit * $bonusper_pro / 100);
//echo $deposit;
		if ($bonusper_pro!=0) {
			$turn_pro = ($deposit + (($deposit) * $bonusper_pro / 100)) * $turnover1;
		}else{
			$turn_pro = $turnover1;
		} 
//echo $turn_pro;
	
if ($get_pro==$namepro and $deposit>=$money) {
			$sum = $deposit + $bonus_pro;
		}else{
			$sum = $deposit;
		}

//echo $sum;
		$usernameufa = $agent_user.$username;
		$status= $api->add_credit($usernameufa,$sum); 
		$status = json_decode($status);
		$status = $status->status;


if ($status==200 and $get_pro==$namepro and $deposit>=$money) {
	$sql = "UPDATE deposit SET  
            confirm_dp='อนุมัติ' , 
            amount_dp='$deposit' ,
            bonus_dp='$bonus_pro' ,
            bankin_dp = 'ธนาคารไทยพาณิชย์' ,
            date_check ='$date_check' ,
            time_check = '$time_check' ,
            turnover = '$turnover1' ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
            $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());

            
            $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
			$result5 = mysqli_query($con, $sql5);
			$row5 = mysqli_fetch_assoc($result5);
			$key = $row5['linedeposit'];



            $sMessage = "ฝากเครดิตออโต้ \nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone_dp."\nโปรโมชั่น ".$get_pro;
				$chOne = curl_init(); 
				curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				curl_setopt( $chOne, CURLOPT_POST, 1); 
				curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				$result = curl_exec( $chOne ); 
				if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
					$result_ = json_decode($result, true); } 
					curl_close( $chOne );

	}elseif($status==200){

		$sql = "UPDATE deposit SET  
            confirm_dp ='อนุมัติ' , 
            amount_dp ='$deposit' ,
            bonus_dp = 0 ,
            bankin_dp = 'ธนาคารไทยพาณิชย์' ,
            date_check ='$date_check' ,
            time_check = '$time_check' ,
            promotion_dp = 'ไม่รับโบนัส' ,
            turnover = 0 ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
            $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
            
            $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
			$result5 = mysqli_query($con, $sql5);
			$row5 = mysqli_fetch_assoc($result5);
			$key = $row5['linedeposit'];



            $sMessage = "ฝากเครดิตออโต้ \nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone_dp."\n"."ไม่รับโบนัส";
				$chOne = curl_init(); 
				curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				curl_setopt( $chOne, CURLOPT_POST, 1); 
				curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				$result = curl_exec( $chOne ); 
				if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
					$result_ = json_decode($result, true); } 
					curl_close( $chOne ); 
	}
//echo $sum;

	}
	}else {
	echo "no update";
	print"<br>";}

}
}

}
}else{ echo 'ระบบออโต้ปิด';}
// คืนยอดเสีย
// $sql5 = "SELECT * FROM withdraw WHERE amount_cashback!=''";
// $result5 = mysqli_query($con, $sql5);

// while($row5 = mysqli_fetch_array($result5)) { 
// 		// $money = $row['dp_pro'];
// 		// $namepro= $row['name_pro'];
// 		$confirm_wd=$row5['confirm_wd'];
// 		$username=$row5['username_wd'];
// 		$sum=$row5['amount_cashback'];
// if ($confirm_wd=='รอดำเนินการ') {
// 		$usernameufa = $agent_user.$username;
		
// 		$status= $api->add_credit($usernameufa,$sum); 
// 		$status = json_decode($status);
// 		$status = $status->status;
// 		if ($status==200) {
// 	$sql = "UPDATE withdraw SET  
//             confirm_wd='อนุมัติ' , 
//            	bankout_wd='คืนยอดเสีย'
//             WHERE username_wd='$username' ORDER BY id DESC LIMIT 1 ";
//             $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
// 	}else{
// 		echo 'คืนยอดเสียไม่สำเร็จ';
// 	}

// }else{
// 	echo 'ไม่มียูสเซอร์ขอรับยอดเสีย';}

// }