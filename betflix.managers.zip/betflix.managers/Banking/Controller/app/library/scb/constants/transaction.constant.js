const errorMsgScb = {
    'code_1011':{
        status: 400,
        statusCode: 1011,
        statusText: 'ไม่มีการทำรายการในบัญชีนี้',
        description: null
    }
}

module.exports = errorMsgScb