<?php include '../inc/header.php'; ?>
<?php include '../Command/body_promotionpopup.php'; ?>
<?php include '../inc/footer.php'; ?>