
<?php
 //error_reporting(0);

require '../config/connectdb.php';
require 'apiufa1062.php';


$sql_scb = "SELECT * FROM bank WHERE name_bank='ธนาคารไทยพาณิชย์' ORDER BY id DESC LIMIT 1";
$result_scb = mysqli_query($con, $sql_scb);
$row_scb = mysqli_fetch_assoc($result_scb);
$status_scb=$row_scb['status_bank'];

if($status_scb=='ปิด'){
echo 'ระบบปิด';
exit;
}
  
$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$agent_user=$row['agent'];
$key = $row['linedeposit'];

$status_auto2 = $row['status_auto2'];



if ($status_auto2=='เปิด') {
  
echo 'ระบบออโต้เปิดทำงานปกติ';

$checkdp = "SELECT * FROM reportscb WHERE bank_acc!='' ORDER BY id DESC LIMIT 100";
$query12 = mysqli_query($con, $checkdp);
foreach ($query12 as $v) {//แตกรายการ scb

$date_check = $v['date_check'];
$time_check = $v['time_check'];
$deposit = $v['amount'];
$transactionDescription2 = $v['type'];
$fromAccount = $v['bank_acc'];
//echo $transactionDescription2;

$turn2=$deposit*2;
if ($transactionDescription2=='ฝากเงิน') {





$sql_checkdp = "SELECT * FROM deposit WHERE date_check='$date_check' AND time_check='$time_check'";
$query2 = mysqli_query($con, $sql_checkdp);
$check2 = $query2->num_rows;
// echo '<br>';
// echo $check2;
// echo '<br>';
//echo $fromAccount;
// echo '<br>';


if ($check2==0) {

$search = "SELECT * FROM member WHERE bankacc_mb LIKE '%$fromAccount%'";
$result = mysqli_query($con, $search);
$check22 = $result->num_rows;
//echo $check22;

//echo '<br>';
while($rowsearch = mysqli_fetch_array($result)) {
$phone = $rowsearch['phone_mb'];
$name_mb = $rowsearch['name_mb'];
$username1 = $rowsearch['username_mb'];
$id_mb = $rowsearch['id_mb'];
$aff = $rowsearch['aff'];


$bank_mb = $rowsearch['bank_mb'];

echo $bank_mb;

  
if ($bank_mb=='ธ.ออมสิน') {
    $bankacc_mb = substr($rowsearch['bankacc_mb'], 6);
}elseif($bank_mb=='ธ.ก.ส.'){
    $bankacc_mb = substr($rowsearch['bankacc_mb'], 6);
}elseif($bank_mb=='ธ.ไทยพาณิชย์'){
    $bankacc_mb = substr($rowsearch['bankacc_mb'], 6);
}else{
    $bankacc_mb = substr($rowsearch['bankacc_mb'], 4);
}
echo  $bankacc_mb;
if ($fromAccount==$bankacc_mb AND $phone!='') {
// echo '<br>';
// echo $phone;
// echo '<br>';
// echo $check2;
// echo '<br>';
// echo $deposit;
// echo '<br>';
// echo $fromAccount;
// echo '<br>';
// echo $transactionDescription2;
// echo '<br>';




  $sql_check3 = "SELECT * FROM deposit WHERE confirm_dp='รอดำเนินการ' AND phone_dp='$phone'";
  $query3 = mysqli_query($con, $sql_check3);

  $check3 = $query3->num_rows;

  $row_pro3 = mysqli_fetch_assoc($query3);
  $get_pro = $row_pro3['promotion_dp'];

  $phone_dp = $row_pro3['phone_dp'];
//echo $get_pro;
  $username = $row_pro3['username_dp'];

  if ($check3==1) {
    
    $sql_promotion="SELECT * FROM promotion WHERE name_pro='$get_pro'";
    $result7 = mysqli_query($con, $sql_promotion);
    $row7 = mysqli_fetch_assoc($result7);
    $money = $row7['dp_pro'];
    $namepro= $row7['name_pro'];
    $bonusper_pro = $row7['bonusper_pro'];
    $dp_pro = $row7['dp_pro'];
    $turn = $row7['turn_pro'];
    $max_pro = $row7['max_pro'];
    //echo $max_pro;
function extract_int($str){
     preg_match('/[^0-9]*([0-9]+)[^0-9]*/', $str, $regs);
     return (intval($regs[1]));
}
$a=$turn;
$turnover1 = extract_int($a);

    $bonus_pro1 = $row7['bonus_pro'] + ($deposit * $bonusper_pro / 100);

    if ($bonus_pro1>$max_pro) {
      $bonus_pro=$max_pro;
    }else{
      $bonus_pro = $row7['bonus_pro'] + ($deposit * $bonusper_pro / 100);
    }


 
//echo $bonus_pro;
    if ($bonusper_pro!=0) {
      $turn_pro = ($deposit + $bonus_pro) * $turnover1;
    }else{
      $turn_pro = $turnover1;
    } 
//echo $turn_pro;
  
if ($get_pro==$namepro and $deposit>=$money) {
      $sum = $deposit + $bonus_pro;
    }else{
      $sum = $deposit;
    }

//echo $sum;
    $usernameufa = $agent_user.$username;
//echo $usernameufa;
    $status= $api->add_credit($usernameufa,$sum); 
    $status = json_decode($status);
    $status = $status->status;
  //echo $status;
    if ($status==200 and $get_pro==$namepro and $deposit>=$money) {
       
     
  $sql = "UPDATE deposit SET  
            confirm_dp='อนุมัติ' , 
            amount_dp='$deposit' ,
            bonus_dp='$bonus_pro' ,
            bankin_dp = 'ธนาคารไทยพาณิชย์' ,
            date_check='$date_check' ,
            time_check='$time_check' ,
            turnover = '$turn_pro' ,
            add_dp = 'AUTO' ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
            $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());

            
      $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
      $result5 = mysqli_query($con, $sql5);
      $row5 = mysqli_fetch_assoc($result5);
      $key = $row5['linedeposit'];



            $sMessage = "ฝากเครดิตออโต้ scb\nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone_dp."\nโปรโมชั่น ".$get_pro;
        $chOne = curl_init(); 
        curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
        curl_setopt( $chOne, CURLOPT_POST, 1); 
        curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
        $headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
        curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
        curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
        $result = curl_exec( $chOne ); 
        if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
          $result_ = json_decode($result, true); } 
          curl_close( $chOne );
           
  }elseif($status==200){
  
    $sql = "UPDATE deposit SET  
            confirm_dp ='อนุมัติ' , 
            amount_dp ='$deposit' ,
            bonus_dp = 0 ,
            bankin_dp = 'ธนาคารไทยพาณิชย์' ,
            date_check='$date_check' ,
            time_check='$time_check' ,
            promotion_dp = 'ไม่รับโบนัส' ,
            turnover = 0 ,
            add_dp = 'AUTO' ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
            $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
            
            $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
      $result5 = mysqli_query($con, $sql5);
      $row5 = mysqli_fetch_assoc($result5);
      $key = $row5['linedeposit'];



            $sMessage = "ฝากเครดิตออโต้ scb\nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone_dp."\n"."ไม่รับโบนัส";
        $chOne = curl_init(); 
        curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
        curl_setopt( $chOne, CURLOPT_POST, 1); 
        curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
        $headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
        curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
        curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
        $result = curl_exec( $chOne ); 
        if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
          $result_ = json_decode($result, true); } 
          curl_close( $chOne ); 
  }




  }//$check3==1
  else{
    $usernameufa = $agent_user.$username1;
// echo $usernameufa;
// echo '<br>';
// echo $deposit;
// echo '<br>';

    $status= $api->add_credit($usernameufa,$deposit); 
    $status = json_decode($status);
    $status = $status->status;
    // echo $status;
    if($status==200){

    $sql = "INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, fromTrue, date_check, time_check, bankin_dp, fromAccount, turnover, add_dp)
             VALUES('$id_mb', '$username1', '$phone', '$bank_mb', '$bankacc_mb','$name_mb', 'อนุมัติ', '$deposit', 'ไม่รับโบนัส', '$aff', '', '0', '$fromTrue', '$date_check', '$time_check', 'ธนาคารไทยพาณิชย์', '$fromAccount', 0, 'AUTO')";

    $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
            
            $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
      $result5 = mysqli_query($con, $sql5);
      $row5 = mysqli_fetch_assoc($result5);
      $key = $row5['linedeposit'];



            $sMessage = "ฝากเครดิตออโต้ scb\nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone."\n"."ไม่รับโบนัส";
        $chOne = curl_init(); 
        curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
        curl_setopt( $chOne, CURLOPT_POST, 1); 
        curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
        $headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
        curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
        curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
        $result = curl_exec( $chOne ); 
        if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
          $result_ = json_decode($result, true); } 
          curl_close( $chOne ); 
  }

  }

}


}







}

}

}//แตกรายการ scb

}else{
  echo 'ระบบออโต้ปิด';
  }
