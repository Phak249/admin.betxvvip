<?php include '../inc/header.php'; ?>
<?php include '../Command/body_activity.php'; ?>
<?php include '../inc/footer.php'; ?>