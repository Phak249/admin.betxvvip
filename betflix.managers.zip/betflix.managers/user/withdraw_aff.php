<?php
include('../connectdb.php'); 
$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
$row = mysqli_fetch_array($result);

// ดึงค่าจากฐานข้อมูล
$key = $row['linewithdraw'];

date_default_timezone_set('Asia/Bangkok');
$id_aff = mysqli_real_escape_string($con, $_POST["id_aff"]);
$username_aff = mysqli_real_escape_string($con, $_POST["username_aff"]);
$phone_aff = mysqli_real_escape_string($con, $_POST["phone_aff"]);
$bank_aff = mysqli_real_escape_string($con, $_POST["bank_aff"]);
$bankacc_aff = mysqli_real_escape_string($con, $_POST["bankacc_aff"]);
$name_aff = mysqli_real_escape_string($con, $_POST["name_aff"]);
$confirm_aff = mysqli_real_escape_string($con, $_POST["confirm_aff"]);

$month_dp = date('Y-m',strtotime('-1 month'));
$aff5 = $username_aff;

$query = "SELECT SUM(amount_dp) FROM deposit WHERE confirm_dp = 'อนุมัติ' AND aff_dp = '$aff5' AND date_dp LIKE '%$month_dp%' AND promotion_dp NOT LIKE '%เครดิตฟรี%'";
$result = mysqli_query($con, $query);
$amount = 0;
while ($row = mysqli_fetch_array($result)) {
    $amount = $row['SUM(amount_dp)'] * $affcashback / 100;
}

include('../cronjob-run/apiufa1062.php');

if ($amount == 0) {
    echo "<script>";
    echo "window.location = 'index.php?do=18'; ";
    echo "</script>";
} else {
    // เช็คซ้ำ
    $month_aff = date('Y-m');
    $check = "SELECT phone_aff FROM withdrawaff WHERE phone_aff = '$phone_aff' AND date_aff LIKE '%$month_aff%'";
    $result1 = mysqli_query($con, $check) or die(mysqli_error($con));
    $num = mysqli_num_rows($result1);

    if ($num > 0) {
        echo "<script>";
        echo "window.location = 'index.php?do=19'; ";
        echo "</script>";
    } else {
        // บันทึกการถอน
        $sql9 = "INSERT INTO withdrawaff (id_aff, username_aff, phone_aff, bank_aff, bankacc_aff, name_aff, confirm_aff, amount_aff) 
                 VALUES ('$id_aff', '$username_aff', '$phone_aff', '$bank_aff', '$bankacc_aff', '$name_aff', 'อนุมัติ', '$amount')";
        $result9 = mysqli_query($con, $sql9) or die ("Error in query: $sql9 " . mysqli_error($con));
    }
}

if ($result9 == TRUE) {
    $usernameufa = $agent . $username_aff;
    $status = $api->add_credit($usernameufa, $amount); 
    $status = json_decode($status);
    $status = $status->status;

    $sMessage = "รับยอดแนะนำเพื่อน \nจำนวนเงิน " . $amount . " บาท\nเบอร์ " . $phone_aff;
    $chOne = curl_init(); 
    curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
    curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0); 
    curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0); 
    curl_setopt($chOne, CURLOPT_POST, 1); 
    curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage); 
    $headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key);
    curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
    curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1); 
    $result = curl_exec($chOne); 
    if (curl_error($chOne)) {
        echo 'error:' . curl_error($chOne);
    } else {
        $result_ = json_decode($result, true);
    }
    curl_close($chOne);
}

// ปิดการเชื่อมต่อ database
mysqli_close($con);

// แจ้งผลการบันทึกและเปลี่ยนเส้นทาง
if ($result9) {
    header("Content-Type: text/html; charset=utf-8");
    echo "<script type='text/javascript'>";
    echo "window.location = 'index.php?do=20'; ";
    echo "</script>";
} else {
    header("Content-Type: text/html; charset=utf-8");
    echo "<script type='text/javascript'>";
    echo "window.location = 'index.php'; ";
    echo "</script>";
}
?>
