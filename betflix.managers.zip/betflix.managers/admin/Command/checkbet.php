
<?php include '../inc/header.php'; ?>
<section class="pcoded-main-container">
  
<div class="pcoded-content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-body">
          <h5 class="text-dark">เช็คเดิมพัน<a href="checkbet.php" class="btn btn-success float-right btn-sm">ย้อนกลับ</a>
          </h5>
          <hr>
          <iframe src="<?php echo $agent_link; ?>" width="100%" height="1000"></iframe>
        </div>
      </div>
    </div>
  </div>
</div>
</section>
<?php include '../inc/footer.php'; ?>