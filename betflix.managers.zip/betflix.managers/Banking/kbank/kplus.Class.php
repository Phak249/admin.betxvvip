<?php
$endpoint = 'ufamc88.info';
class Kplus
{

    private $endpoint;

    public function __construct($endpointIP)
    {
        if ($endpointIP == "") {
            die("Check Your endpointIP");
        } else {
            $this->endpoint = $endpointIP;
        }
    }

    //&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1032;&#1072;&#1105;&#1030;&#1072;&#1105;&#1118;&#1072;&#1105;&#1027;&#1072;&#1105;&#1030;&#1072;&#1105;&#1032;
    public function getBalance()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://' . $this->endpoint . '/balance');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return array();
        }
        return json_decode($result, true);
    }

    //&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1032;&#1072;&#1105;&#1030;&#1072;&#1105;&#1118;&#1072;&#1105;&#1027;&#1072;&#1105;&#1030;&#1072;&#1105;&#1032;
    public function getTransactions()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://' . $this->endpoint . '/activities');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return array();
        }
        return json_decode($result, true);
    }

    //&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1032;&#1072;&#1105;&#1030;&#1072;&#1105;&#1118;&#1072;&#1105;&#1027;&#1072;&#1105;&#1030;&#1072;&#1105;&#1032; &#1072;&#8470;&#1026;&#1072;&#1105;&#1026;&#1072;&#1105;&#1030;&#1072;&#1105;�&#1072;&#1105;&#1026;&#1072;&#1105;�
    public function getTransactionDetail($rqUid)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://' . $this->endpoint . '/activity-detail/' . $rqUid);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return array();
        }
        return json_decode($result, true);
    }

    //&#1072;&#1105;�&#1072;&#1105;&#1032;&#1072;&#1105;�&#1072;&#1105;&#1026;&#1072;&#1105;&#1028;&#1072;&#1105;�&#1072;&#1105;&#1113;&#1072;&#1105;&#1114;&#1072;&#1105;&#8470;&#1072;&#8470;�&#1072;&#1105;&#1032;&#1072;&#1105;�&#1072;&#1105;&#1113;&#1072;&#1105;&#1027;&#1072;&#8470;&#1026;&#1072;&#1105;�&#1072;&#1105;�&#1072;&#8470;�&#1072;&#1105;�&#1072;&#1105;�&#1072;&#8470;&#1026;&#1072;&#1105;�&#1072;&#1105;&#1169;&#1072;&#1105;�
    public function transferVerify($toBankCode, $toAccount, $amount)
    {
        $headers = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://' . $this->endpoint . '/inquire-for-transfer-money/');
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'toBankCode=' . $toBankCode . '&toAccount=' . $toAccount . '&amount=' . $amount . '');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        
        $result = curl_exec($ch);
        $data =  json_decode($result, true);
        if (curl_errno($ch)) {
            return ['status' => false, 'msg' => $data];
        }
        return $data;
    }

    //&#1072;&#1105;&#1118;&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1118;&#1072;&#1105;�&#1072;&#1105;�&#1072;&#8470;�&#1072;&#1105;�&#1072;&#1105;�&#1072;&#8470;&#1026;&#1072;&#1105;�&#1072;&#1105;&#1169;&#1072;&#1105;�
   

    public function transferConfrim($kbankInternalSessionId)
    {
        $headers = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://' . $this->endpoint . '/transfer-money78/' . $kbankInternalSessionId);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return json_decode($result, true);
        }
        curl_close($ch);
        return json_decode($result, true);
    }

}
