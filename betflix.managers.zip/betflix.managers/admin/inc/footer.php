</div>
                    <!-- /.content-wrapper -->
                    <footer class="main-footer">
                        <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
                        All rights reserved.
                        <div class="float-right d-none d-sm-inline-block">
                            <b>Version</b> 3.0.5
                        </div>
                    </footer>

                    <tw-expired-noti />
                </div>
            </body>
            <audio id="notialert" src="" preload="auto" autoplay style="display: none" />
        </main>
    </div>

    <script src="pusher/p.js"></script>




    <script src="../assets/js/app.js"></script>
    <script type="text/javascript" src="../assets/jQuery-DoubleScroll/jquery.doubleScroll.js"></script>
    <script src="../assets/js/uni.js"></script>
    <script src="../assets/js/dist/jquery.coloring-pick.min.js"></script>
    <link rel="stylesheet" href="../assets/css/dist/jquery.coloring-pick.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/DataTables/datatables.min.css" />
    <script type="text/javascript" src="../assets/DataTables/datatables.min.js"></script>

    <!--admin -->
    <script type="text/javascript" src="../assets/LuckySpin/js/setting.js"></script>



    <script>
        function swalIncomingLotto() {
            swal.fire(
                'ระบบหวย',
                'หากสนใจกรุณาติดต่อทีมงานที่กลุ่มประสานงาน',
                'info'
            )
        };
    </script>
    <script>
        $(`.login_btn,
        a[href="dashboard"],
        a[href="deposit"],
        a[href="withdraw"],
        a[href="deposit-withdraw"],
        a[href="credit-mobile"],
        a[href="rock-money"],
        a[href="promote"],
        a[href="bonus"],
        a[href="iBanking"],
        a[href="admins"],
        a[href="marketer"],
        a[href="bankaccount"],
        a[href="agent"],
        a[href="profile"],
        a[href="#"]`).click(function () {
            $("#notialert")[0].click();
        });
    </script>
    <div id="ajax_responses">

    </div>
</body>

</html>