
<?php
require '../config.php';
error_reporting(0);
header("Content-Type: text/html; charset=utf-8");
$sql = "SELECT * FROM setting";
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);
$status_transfer=$row['status_auto'];
$limit_scb = $row['max_autowd'];
$status_auto2 = $row['status_auto2'];

if ($status_auto2=='เปิด') {
echo 'ระบบถอนเปิดอยู่';
if($status_transfer!='เปิด'){
	echo 'ฟังชั่นปิดอยู่';
exit();
}



//หากลูกค้ารับโปรวันนี้ จะไม่สามารถถอนออโต้ได้
$sql = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND bank_wd!="ทรูวอเล็ต" ORDER by id asc LIMIT 1';
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);
$phone2 = $row['phone_wd'];
//echo $phone;

$today_pro = date('Y-m-d');
$sql2 = "SELECT * FROM deposit WHERE phone_dp = $phone2 AND date_dp LIKE '%$today_pro%' AND promotion_dp!='ไม่รับโบนัส' AND confirm_dp='อนุมัติ'";
$query2 = $server->query($sql2);
$row55 = mysqli_fetch_assoc($query2);
$check2 = $query2->num_rows;
$phonepro = $row55['phone_dp'];

$propro = $row55['promotion_dp'];
//echo $check2;

if ($check2>0) {
	echo 'ลูกค้ารับโปรก่อนหน้านี้';
	$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
					$result5 = $server->query($sql5);
					$row5 = mysqli_fetch_assoc($result5);
					$key = $row5['linewithdraw'];

										$sMessage = "มีรายการถอนค้างอยู่ \nเบอร์ ".$phonepro." \nลูกค้ารับโปรโมชั่น \nกรุณาตรวจสอบ \nโปรโมชั่นที่รับวันนี้ : ".$propro;
										$chOne = curl_init(); 
										curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
										curl_setopt( $chOne, CURLOPT_POST, 1); 
										curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
										$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
										curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
										$result = curl_exec( $chOne ); 
										if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
											$result_ = json_decode($result, true); } 
											curl_close( $chOne );
exit();
}else{	


$withdraw = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND bank_wd!="ทรูวอเล็ต" AND lastpro="ไม่รับโบนัส" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1';//ถ้าไม่ต้องการเช็คคนที่รับโปร ก่อนถอน เอา lastpro="ไม่รับโบนัส" ออก

$result = $server->query($withdraw);
$withdraw=array();
foreach ($result as $row) {


	
	$sql1 = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND bank_wd!="ทรูวอเล็ต" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1';
	$result1 = $server->query($sql1);
	$row1 = mysqli_fetch_assoc($result1);

	$row['bank_name1']=$row1['bank_wd'];
	$row['bank_number']=$row1['bankacc_wd'];

//echo $row['bank_number'];

	array_push($withdraw,$row);


}

 
?>


<?php $i=1; foreach ($withdraw as $key => $value) {
     $credit=$value['amount_wd'];
	//echo $credit;
	 if ($credit<=$limit_scb){
		 $phone=$value ['phone_wd'];
			echo 'ถอนได้';
		
			$sql = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND bank_wd!="ทรูวอเล็ต" ORDER by id asc LIMIT 1';
			$result = $server->query($sql);
			$row = mysqli_fetch_assoc($result);
			$pin_wd = $row['pin_wd'];

			if ($pin_wd=='unknown6134') {
			
			//echo $value['bank_name1'];

			include_once 'api_scb_trans.php';
		 	
			$accountTo=$value ['bank_number'];
			$accountToBankCode=code($value['bank_name1']);  
			$amount=$credit;
			}

			echo $accountTo;
			echo '<br>';
			echo $accountToBankCode;
			echo '<br>';
			echo $amount;
			echo '<br>';



			$transferType="ORFT";
			if ($accountToBankCode=='014') {
			  $transferType="3RD";
			}
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://fasteasy.scbeasy.com/v2/transfer/verification",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS =>'{"accountFrom":"'.$GLOBALS["accountFrom"].'","accountFromType":"2","accountTo":"'.$accountTo.'","accountToBankCode":"'.$accountToBankCode.'","amount":"'.$amount.'","annotation":null,"transferType":"'.$transferType.'"}',
			  CURLOPT_HTTPHEADER => array(
				'Accept-Language:      th',
				'Api-Auth: '.$Auth1,
				'Content-Type:  application/json;charset=UTF-8'
			  ),
			));

			$response = curl_exec($curl);
			$data = json_decode($response,true);
			$check=$data['status']['description'];
			if ($check=="จำนวนเงินในบัญชีไม่เพียงพอ กรุณาเลือกบัญชีอื่น") {
			  $data = array ('msg'=>'จำนวนเงินในบัญชีไม่เพียงพอ กรุณาเลือกบัญชีอื่น','status'=>500);
			  echo json_encode($data);
			  exit();
			}

			$totalFee=$data['data']['totalFee'];
			$scbFee=$data['data']['scbFee'];
			$botFee=$data['data']['botFee'];
			$channelFee= $data['data']['channelFee'];
			$accountFromName= $data['data']['accountFromName'];
			$accountTo= $data['data']['accountTo'];
			$accountToName= $data['data']['accountToName'];
			$accountToType= $data['data']['accountToType'];
			$accountToDisplayName= $data['data']['accountToDisplayName'];
			$accountToBankCode= $data['data']['accountToBankCode'];
			$pccTraceNo= $data['data']['pccTraceNo'];
			$transferType= $data['data']['transferType'];
			$feeType= $data['data']['feeType'];
			$terminalNo= $data['data']['terminalNo'];
			$sequence= $data['data']['sequence'];
			$transactionToken= $data['data']['transactionToken'];
			$bankRouting= $data['data']['bankRouting'];
			$fastpayFlag= $data['data']['fastpayFlag'];
			$ctReference= $data['data']['ctReference'];

			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://fasteasy.scbeasy.com/v3/transfer/confirmation",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS =>"{\"accountFrom\":\"$accountTo\",\"accountFromName\":\"" .$accountFromName. "\",\"accountFromType\":\"2\",\"accountTo\":\"" .$accountTo. "\",\"accountToBankCode\":\"" .$accountToBankCode. "\",\"accountToName\":\"" . $accountToName . "\",\"amount\":\"" . $amount . "\",\"botFee\":0.0,\"channelFee\":0.0,\"fee\":0.0,\"feeType\":\"\",\"pccTraceNo\":\"" . $pccTraceNo . "\",\"scbFee\":0.0,\"sequence\":\"" . $sequence. "\",\"terminalNo\":\"" . $terminalNo . "\",\"transactionToken\":\"" . $transactionToken. "\",\"transferType\":\"" . $transferType. "\"}",
			  CURLOPT_HTTPHEADER => array(
				'Api-Auth: '.$Auth1,
				'Content-Type:  application/json;charset=UTF-8'
			  ),
			));

			$sql4 = 'SELECT * FROM bank WHERE name_bank="ธนาคารไทยพาณิชย์" AND status_bank="เปิด"';
				$result4 = $server->query($sql4);
				$row4 = mysqli_fetch_assoc($result4);

				$bankout_no=$row4['bankacc_bank'];


			$response = curl_exec($curl);
			curl_close($curl);
			$data = json_decode($response,true);
			$status=$data['status']['description'];
			
			if ($status=="สำเร็จ") {
									
				$sql = "UPDATE withdraw SET  
            					confirm_wd='อนุมัติ' ,
            					edit_wd='AUTO' , 
            					pin_wd='',
            					bankout_wd='ธนาคารไทยพาณิชย์ $bankout_no' 
            					WHERE phone_wd='$phone' AND confirm_wd='รอดำเนินการ'";

			if ($server->query($sql) === TRUE) {
			}
			$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
			$result5 = mysqli_query($con,$sql5);
			$row5 = mysqli_fetch_assoc($result5);
			$key = $row5['linewithdraw'];

			$sMessage = "BOT อนุมัติถอน \nจำนวนเงิน ".$amount." บาท\nเบอร์ ".$phone;
			$chOne = curl_init(); 
				curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				curl_setopt( $chOne, CURLOPT_POST, 1); 
				curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				$result = curl_exec( $chOne ); 
				if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
					$result_ = json_decode($result, true); } 
					curl_close( $chOne );
									
									
					$data = array ('msg'=>"ทำรายการ สำเร็จ!",'status'=>200);
					echo json_encode($data);
					exit();
				
										
				$data = array ('msg'=>'success!','phone'=>$GLOBALS["phone"],'id'=>$GLOBALS["id"],'status'=>200);
					echo json_encode($data);
					exit();
								  
				}else{
										  
					$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
					$result5 = mysqli_query($con,$sql5);
					$row5 = mysqli_fetch_assoc($result5);
					$key = $row5['linewithdraw'];

					$sMessage = "BOT! ธนาคารถอนมีปัญหา \nจำนวนเงิน ".$amount." บาท\nเบอร์ ".$phone;
					$chOne = curl_init(); 
					curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
					curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
					curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
					curl_setopt( $chOne, CURLOPT_POST, 1); 
					curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
					$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
					curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
					curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
					$result = curl_exec( $chOne ); 
						if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
							$result_ = json_decode($result, true); } 
							curl_close( $chOne );
									
							$data = array ('msg'=>$status,'status'=>500);
								echo json_encode($data);
								exit();
							}	
					 


		 
	 }else{
					$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
					$result5 = mysqli_query($con,$sql5);
					$row5 = mysqli_fetch_assoc($result5);
					$key = $row5['linewithdraw'];

										$sMessage = "BOT! มีรายการถอนค้างอยู่ \nจำนวนเงิน ".$amount." บาท\nเบอร์ ".$phone;
										$chOne = curl_init(); 
										curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
										curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
										curl_setopt( $chOne, CURLOPT_POST, 1); 
										curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
										$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
										curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
										$result = curl_exec( $chOne ); 
										if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
											$result_ = json_decode($result, true); } 
											curl_close( $chOne );
				
					$data = array ('msg'=>$status,'status'=>500);
					echo json_encode($data);
					
		 echo 'เกินงบ ถอนไม่ได้';
	 }


	?>
 

<?php $i++; } 
}
}else{ echo 'ระบบออโต้ปิด';}


 ?>
