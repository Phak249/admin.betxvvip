<?php include '../inc/header.php'; ?>
<?php include '../Command/body_setting.php'; ?>
<?php include '../inc/footer.php'; ?>