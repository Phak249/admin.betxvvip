
<?php
error_reporting(0);

require '../connectdb.php';
require '../kbank525698/index.php';
// require 'line.php';
//require'../kbank525698/kplus.Class.php';
function getDatetimeNow() {
  $tz_object = new DateTimeZone('Asia/Bangkok');
  //date_default_timezone_set('Brazil/East');

  $datetime = new DateTime();
  $datetime->setTimezone($tz_object);
  return $datetime->format('Y\-m\-d\ h:i:s');
}
$timeNow = getDatetimeNow();


if (!isset($_GET['c']) || $_GET['c'] != 'checkbank') {
  exit('BOT SPAM');
}



// echo '<br>';
if ($balanceKbank != '') {
  $sql8 = "UPDATE credit SET
            credit_kbank='$balanceKbank'
            WHERE id=1";
  $result9 = mysqli_query($con, $sql8) or die("Error in query: $sql " . mysqli_error($con));
}

// $sql2 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
// $result = mysqli_query($con, $sql2);
// $row = mysqli_fetch_assoc($result);
// $lineregister = $row['lineregister'];



//$api2 = new Kplus($endpoint);
$data = json_encode($api2->getBalance(), JSON_UNESCAPED_UNICODE);
$balance = json_decode($data);
$balanceKbank = $balance->outstandingBalance;



//echo $balanceKbank;
if ($balanceKbank != '') {
  echo 'ดึงรายการ Kbank สำเร็จ';
  //   sendLine($lineregister, 'ดึงรายการ Kbank สำเร็จ');
} else {
  echo 'เช็ค Kbank ด่วน!!!';
  //   sendLine($lineregister, 'เช็ค Kbank ด่วน!!!');
}


$data3 = json_encode($api2->getTransactions());
print_r($data3);
//exit($data3);
$balance4 = json_decode($data3);
if (count($balance4->activityList) > 20) {
  $cc = array_chunk($balance4->activityList, 20);
  $balance4->activityList = $cc[0];
}
// echo '<pre>';
// print_r($balance4);
// die;

$sql20 = 'INSERT INTO reportkbank(code, amount, fromacc, frombank, type, toacc, tobank, toname, fromname, date) VALUES ';

foreach ($balance4->activityList as $v) { //แตกรายการ kbank
  $code_dp = $v->rqUid;

  $deposit = $v->amount;
  $transactionDescription2 = $v->transactionDescription;
  $transactionDescription = $v->transactionType;
  //$fromAccount1 = $v->fromAccountNo;
  $kplus = $v->channel;
  $toacc = $v->toAccountNo;

  $json = json_encode($api2->getTransactionDetail($code_dp));
  $balance2 = json_decode($json);

  $fromAccount4 = $balance2->fromAccountNo;
  $fromAccountName3 = $balance2->fromBankName;
  $toBankName = $balance2->toBankName;
  $toname = $balance2->toAccountName;
  $fromname = $balance2->fromAccountName;
  echo $fromname . '<br>';
  if ($fromAccountName3 == 'ธ.ทหารไทยธนชาต') {
    $fromAccountName = 'ธ.ทหารไทยธนชาติ';
  } else {
    $fromAccountName = $fromAccountName3;
  }

  //echo $toBankName;
  if ($kplus == 'K PLUS') {
    $fromAccount1 = $v->fromAccountNo;
  } elseif ($kplus == 'LINE BK') {
    $fromAccount1 = $v->fromAccountNo;
  } elseif ($kplus == 'K PLUS SME') {
    $fromAccount1 = $v->fromAccountNo;
  } elseif ($kplus == 'K-Cash Connect Plus') {
    $fromAccount1 = $v->fromAccountNo;
  } else {
    $fromAccount1 = $balance2->fromAccountNo;
  }




  if ($kplus == 'K PLUS') {
    $fromName = $v->fromAccountName;
  } elseif ($kplus == 'LINE BK') {
    $fromName = $v->fromAccountName;
  } elseif ($kplus == 'K PLUS SME') {
    $fromName = $v->fromAccountName;
  } else {
    $fromName = $balance2->fromAccountName;
  }


  $vowels2 = array("-", "x");
  $fromAccount = str_replace($vowels2, "", $fromAccount1);
  //echo $fromAccount;die;



  $checkdp = "SELECT id FROM reportkbank WHERE code='$code_dp'";
  $query12 = mysqli_query($con, $checkdp);
  $check12 = $query12->num_rows;

  //echo $check12;die;
  if ($fromAccount != '') {
    // code...

    if ($check12 == 0) {
      echo $fromName . '<br>';
      $sql20 .= "('$code_dp', '$deposit',  '$fromAccount1',  '$fromAccountName',  '$transactionDescription2',  '$toacc',  '$toBankName',  '$toname',  '$fromName','$timeNow'),";
    }
  } elseif ($transactionDescription2 == 'โอนเงิน') {
    if ($check12 == 0) {
      $sql20 = "('$code_dp', '$deposit',  '$fromAccount1',  '$fromAccountName',  '$transactionDescription2',  '$toacc',  '$toBankName',  '$toname',  '$fromName','$timeNow'),";
    }
  }
  //die;

}

if ($sql20 != 'INSERT INTO reportkbank(code, amount, fromacc, frombank, type, toacc, tobank, toname, fromname, date) VALUES ') {
  $sql20 = rtrim($sql20, ',');
  $sql20 .= ';';
  $result = mysqli_query($con, $sql20) or die("Error in query: $sql20 " . mysqli_error($con));
}
