<aside class="main-sidebar sidebar-dark-primary elevation-4" :class="{ 'sidebar-open': open }"
    style="background: rgb(58, 63, 81); position: fixed;">
    <!-- Brand Logo -->
    <div style="text-align: center;">
      <router-link to="/dashboard"
        class="brand-link bg_contain_sidebar_menu router-link-exact-active router-link-active" aria-current="page"
        style="background: rgb(58, 63, 81) !important;">
        <div class="flex_icon_menu_center">
          <img src="../assets/img/logo-icon.png" alt="AdminLTE Logo" width="18"
            class="brand-image hide-logo center-moz-icon">
        </div>
        <div class="brand-text" style="text-align: center;">

        </div>
      </router-link>
    </div>
    <!-- Sidebar -->
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <img src="../assets/img/logo-icon.png" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
        <router-link to="#" class="d-block">Alexander Pierce</router-link>
      </div>
    </div>
    <nav class="pcoded-navbar menupos-fixed menu-dark">
        <div class="navbar-wrapper  ">
            <div class="slimScrollDiv" style="position: relative; overflow: scroll; width: auto; height: 100%;">
                <ul class="nav pcoded-inner-navbar ">
                    <li class="nav-item pcoded-menu-caption">
                        <label>เมนู</label>
                    </li>
                    <li class="nav-item">
                        <a href="index.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-tachometer-alt"></i>
                            </span>
                            <span class="pcoded-mtext">Dashboard</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="report.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-file-alt"></i>
                            </span>
                            <span class="pcoded-mtext">รายงาน</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="setting.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-cogs"></i>
                            </span>
                            <span class="pcoded-mtext ">ตั้งค่า</span>
                        </a>
                    </li>
                    
                    <?php
                    //ทำตัวเลขแจ้งเตือน
                        $today_new = date('Y-m-d');
                        $rrt = "SELECT * FROM member WHERE phone_mb !='' AND date_mb LIKE '%$today_new%'" or die("Error:" . mysqli_error());
                        $result = mysqli_query($con, $rrt);
                        // echo('$result');
                        // print_r($result);
                        $rowcount=mysqli_num_rows($result);
                        //printf(" %d \n",$rowcount);
                        //echo($rowcount);
                    ?> 
                    <li class="nav-item">
                        <a href="member.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-users-cog"></i>
                            </span>
                            <span class="pcoded-mtext">สมาชิกใหม่</span>
                            <button type="button" class="btn btn-success" style="float: right;">
                            <span class="badge badge-light"><?php echo($rowcount); ?></span>
                            
                            </button>
                        </a>
                    </li>
                    <?php
                    //ทำตัวเลขแจ้งเตือน
                        $rrt1 = "SELECT * FROM deposit WHERE confirm_dp='รอดำเนินการ'" or die("Error:" . mysqli_error());
                        $result1 = mysqli_query($con, $rrt1);
                        // echo('$result');
                        // print_r($result);
                        $rowcount1=mysqli_num_rows($result1);
                        //printf(" %d \n",$rowcount2);
                        //echo($rowcount2);
                    ?>
                    <li class="nav-item">
                        <a href="deposit.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">รายการฝาก</span>
                            <button type="button" class="btn btn-primary" style="float: right;">
                            <span class="badge badge-light"><?php echo($rowcount1); ?></span>
                            
                            </button>
                        </a>
                    </li>

                    <?php
                    //ทำตัวเลขแจ้งเตือน
                        $rrt2 = "SELECT * FROM withdraw WHERE confirm_wd='รอดำเนินการ' AND pin_wd='unknown6134' "  or die("Error:" . mysqli_error());
                        $result2 = mysqli_query($con, $rrt2);
                        // echo('$result');
                        // print_r($result);
                        $rowcount2=mysqli_num_rows($result2);
                        //printf(" %d \n",$rowcount2);
                        //echo($rowcount2);
                    ?>

                    <li class="nav-item">
                        <a href="withdraw.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">รายการถอน</span>
                            <button type="button" class="btn btn-danger" style="float: right;">
                            <span class="badge badge-light"><?php echo($rowcount2); ?></span>
                            
                            </button>
                        </a>
                    </li>
                    <?php
                    //ทำตัวเลขแจ้งเตือน
                        $rrt3 = "SELECT * FROM withdrawaff WHERE confirm_aff='รอดำเนินการ'" or die("Error:" . mysqli_error());
                        $result3 = mysqli_query($con, $rrt3);
                        // echo('$result');
                        // print_r($result);
                        $rowcount3=mysqli_num_rows($result3);
                        //printf(" %d \n",$rowcount2);
                        //echo($rowcount2);
                    ?>
                    <li class="nav-item">
                        <a href="withdrawaff.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">ถอนแนะนำ</span>
                            <button type="button" class="btn btn-warning" style="float: right;">
                            <span class="badge badge-light"><?php echo($rowcount3); ?></span>
                            
                            </button>
                        </a>
                    </li>
              
                    <!--<li class="nav-item">
                        <a href="checkbet.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-check-square"></i>
                            </span>
                            <span class="pcoded-mtext">เช็คเดิมพัน</span>
                        </a>
                    </li>
                     
                    <li class="nav-item">
                        <a href="member_all.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-users-cog"></i>
                            </span>
                            <span class="pcoded-mtext">สมาชิกทั้งหมด</span>
                           
                        </a>
                    </li> -->
                    <li class="nav-item">
                        <a href="search_member_all.php?act=100" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-users-cog"></i>
                            </span>
                            <span class="pcoded-mtext">ค้นหาสมาชิก</span>
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="deposit_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">ประวัติรายการฝาก</span>
                            
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="free_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">ประวัติเครดิตฟรี</span>
                            
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="spin_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">ประวัติหมุนวงล้อ</span>
                            
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="change_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">ประวัติแลกพ้อยด์</span>
                            
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="withdraw_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-coins"></i>
                            </span>
                            <span class="pcoded-mtext">ประวัติรายการถอน</span>
                            
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="aff_report.php" class="nav-link ">
                            <span class="pcoded-micon">
                               <i class="fas fa-network-wired"></i>
                            </span>
                            <span class="pcoded-mtext">รายการแนะนำเพื่อน</span>
                            
                        </a>
                    </li>
                    <?php

                    $sql997 = "SELECT * FROM bank WHERE name_bank='ธนาคารไทยพาณิชย์' ORDER BY id DESC LIMIT 1 ";
          $result997 = mysqli_query($con, $sql997) or die ("Error in query: $sql " . mysqli_error());
          $row997 = mysqli_fetch_array($result997);
          $bankacc = $row997['bankacc_bank'];
          if ($bankacc!='') {
        
   
                      echo '<li class="nav-item">
                        <a href="scb_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-plus-square"></i>
                            </span>
                            <span class="pcoded-mtext">รายการ SCB</span>
                        </a>
                    </li>';
                       } ?>
                    <?php

                    $sql7 = "SELECT * FROM bank WHERE name_bank='ธนาคารกสิกรไทย' ORDER BY id DESC LIMIT 1 ";
          $result7 = mysqli_query($con, $sql7) or die ("Error in query: $sql " . mysqli_error());
          $row7 = mysqli_fetch_array($result7);
          $token = $row7['token_kbank'];
          if ($token!='') {
        
   
                      echo '<li class="nav-item">
                        <a href="kbank_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-plus-square"></i>
                            </span>
                            <span class="pcoded-mtext">รายการ KBANK</span>
                        </a>
                    </li>';
                       } ?>
                        <?php

                    $sql97 = "SELECT * FROM bank WHERE name_bank='ทรูวอเล็ต' ORDER BY id DESC LIMIT 1 ";
          $result97 = mysqli_query($con, $sql97) or die ("Error in query: $sql " . mysqli_error());
          $row97 = mysqli_fetch_array($result97);
          $bankacc = $row97['bankacc_bank'];
          if ($bankacc!='') {
        
   
                      echo '<li class="nav-item">
                        <a href="true_history.php" class="nav-link ">
                            <span class="pcoded-micon">
                                <i class="fas fa-plus-square"></i>
                            </span>
                            <span class="pcoded-mtext">รายการ True</span>
                        </a>
                    </li>';
                       } ?>
                       <!-- <li class="nav-item">
                        <a href="affiliate.php" class="nav-link ">
                            <span class="pcoded-micon">
                               <i class="fas fa-handshake"></i>
                            </span>
                            <span class="pcoded-mtext">พันธมิตร</span>
                            
                        </a>
                    </li> -->
                    <li class="nav-item">
                        <a href="logout.php" onclick="return confirm('ยืนยันการออกจากระบบ')">
                            <span class="pcoded-micon">
                                <i class="fas fa-sign-out-alt"></i>
                            </span>
                            <span class="pcoded-mtext">ออกระบบ</span>
                        </a>
                    </li>
                    
                </ul>
                <br><br><br><br>
                <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 701px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 595px;"></div></div></div>
            </div>
        </nav>
  </aside>
  