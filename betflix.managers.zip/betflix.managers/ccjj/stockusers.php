
<?php
require '../connectdb.php';
include '../class/betflix.php';

$sql = "SELECT * FROM member WHERE `status` =2";
$result = mysqli_query($con, $sql) or die("Error in query: $sql ");
$num = mysqli_num_rows($result);

function generateRandomString($length = 5)
{
	return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
}

$username = generateRandomString();

if ($num < 30) {
	$api = new Betflix();
	$username = generateRandomString();
	$password = urlencode('aa123456');

	$register = $api->register($username, $password);

	if (!$register->error_code) {
		$sql = "INSERT INTO member (username_mb, password_ufa,status) VALUES('$username', '$password',2)";
		if ($con->query($sql)) {
			echo "successfully";
			exit();
		} else {
			exit(json_encode($register));
		}
	} else {
		exit(json_encode($register));
	}
} else {
	echo 'สต็อกยูสเซอร์เต็มแล้ว';
}


?>
