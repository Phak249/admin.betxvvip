<?php
 //error_reporting(0);
// require '../connectdb.php';
// $sql = "SELECT * FROM setting";
// $result = mysqli_query($con,$sql);
// $row = mysqli_fetch_assoc($result);

// $agent_user='';
// $GLOBALS["api_betflix"]='';
// $GLOBALS["apikey"]='';

 
function agentuser(){
		$agentuser='bdaccdemo0'; # ใส่ยุสเอเย่น
		return $agentuser;
} 
function api_betflix(){
		$api_betflix='pIZkwgh7xandGQrc'; # ใส่ api-betflix
		return $api_betflix;
} 
function xapikey(){
		$api_betflix='9cb07f925b2fc376387ae7f8a30bdd3d'; # ใส่ api-key
		return $api_betflix;
}

function Balance($username=null){
							 
	$curl = curl_init();
				curl_setopt_array($curl, array(
				  CURLOPT_URL => 'https://api.bfx.fail/v4/user/balance',
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => '',
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => 'POST',
				  CURLOPT_POSTFIELDS => 'username='.$username,
				  CURLOPT_HTTPHEADER => array(
					'x-api-betflix: '.api_betflix(),
					'x-api-key: '.xapikey(),
					'Content-Type: application/x-www-form-urlencoded'
				  ),
				));

				$response = curl_exec($curl);
				curl_close($curl);
				return $response;
}

function turnover($username=null){				 
		date_default_timezone_set("Asia/Bangkok");
		$start_date=date('Y-m-d');  
		$end_date=date('Y-m-d');  
 
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => 'https://api.bfx.fail/v4/report/summary?start='.$start_date.'&end='.$end_date.'&username='.$username,
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => '',
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => 'GET',
			  CURLOPT_HTTPHEADER => array(
				'x-api-betflix: '.api_betflix(),
				'x-api-key: '.xapikey(),
				
			  ),
			));

			$response = curl_exec($curl);
			curl_close($curl);
 			return $response;
}
function withdraw($username=null,$credit=null){

		$ran=(rand(10000,99999));
					$curl = curl_init();
					curl_setopt_array($curl, array(
					  CURLOPT_URL => 'https://api.bfx.fail/v4/user/transfer',
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => '',
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 0,
					  CURLOPT_FOLLOWLOCATION => true,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => 'POST',
					  CURLOPT_POSTFIELDS => 'username='.$username.'&amount=-'.$credit.'&ref=with'.$ran,
					  CURLOPT_HTTPHEADER => array(
						'x-api-betflix: '.api_betflix(),
						'x-api-key: '.xapikey(),
						'Content-Type: application/x-www-form-urlencoded'
					  ),
					));
					$response = curl_exec($curl);
					curl_close($curl);
					return $response;
}
function deposit($username=null,$credit=null){

					$ran=(rand(10000,99999));
					$curl = curl_init();
					curl_setopt_array($curl, array(
					  CURLOPT_URL => 'https://api.bfx.fail/v4/user/transfer',
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => '',
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 0,
					  CURLOPT_FOLLOWLOCATION => true,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => 'POST',
					  CURLOPT_POSTFIELDS => 'username='.$username.'&amount='.$credit.'&ref=dps'.$ran,
					  CURLOPT_HTTPHEADER => array(
						'x-api-betflix: '.api_betflix(),
						'x-api-key: '.xapikey(),
						'Content-Type: application/x-www-form-urlencoded'
					  ),
					));
					$response = curl_exec($curl);
					curl_close($curl);
					return $response;

}

function register($username=null,$password=null){
			$ran=(rand(100,100));
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => 'https://api.bfx.fail/v4/user/register',
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => '',
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => 'POST',
			  CURLOPT_POSTFIELDS => 'username='.$username.'&password='.$password,
			  CURLOPT_HTTPHEADER => array(
				'x-api-betflix: '.api_betflix(),
				'x-api-key: '.xapikey(),
				'Content-Type: application/x-www-form-urlencoded'
			  ),
			));
			$response = curl_exec($curl);
			curl_close($curl);
			return $response;
}

function agentinfo(){
 
			$curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => 'https://api.bfx.fail/v4/agent/balance?upline='.agentuser(),
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => '',
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => 'GET',
			  CURLOPT_HTTPHEADER => array(
				'x-api-betflix: '.api_betflix(),
				'x-api-key: '.xapikey(),
				'Content-Type: application/x-www-form-urlencoded'
			  ),
			));
			$response = curl_exec($curl);
			curl_close($curl);
			return $response;
}


//echo Balance('b42ppk88test');
 //echo deposit('b42ppk88test',1);
//echo agentinfo();
 //echo withdraw('b42ppk88test',1);
//echo register('test3','aa123456');
//echo '<br>';
$data2 = Balance($agent.$username_mb);
$Balance1=json_decode($data2);
$Balance=$Balance1->data->balance;

$data3 = agentinfo();
$Balance3=json_decode($data3);
$Balance33=$Balance3->data->total_credit;
//echo $Balance;
?>