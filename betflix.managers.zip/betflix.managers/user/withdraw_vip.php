<?php
include('../config/connectdb.php');  // Connect to the database

// Retrieve settings
$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
$row = mysqli_fetch_array($result);
$key = $row['linewithdraw'];  // Using key from row

// Retrieve POST data
$id_vip = mysqli_real_escape_string($con, $_POST["id_vip"]);
$username_vip = mysqli_real_escape_string($con, $_POST["username_vip"]);
$amount_vip = mysqli_real_escape_string($con, $_POST["amount_vip"]);
$phone_vip = mysqli_real_escape_string($con, $_POST["phone_vip"]);
$bank_vip = mysqli_real_escape_string($con, $_POST["bank_vip"]);
$bankacc_vip = mysqli_real_escape_string($con, $_POST["bankacc_vip"]);
$name_vip = mysqli_real_escape_string($con, $_POST["name_vip"]);
$confirm_vip = mysqli_real_escape_string($con, $_POST["confirm_vip"]);
$note_vip = mysqli_real_escape_string($con, $_POST["note_vip"]);

// Check if there's an existing withdrawal request for the phone number
$check = "SELECT phone_vip FROM withdrawvip WHERE confirm_vip = 'รอดำเนินการ' AND phone_vip = '$phone_vip'";
$result1 = mysqli_query($con, $check);
$num = mysqli_num_rows($result1);

include('../cronjob-run/apiufa1062.php');

if ($num > 0) {
    echo "<script>";
    echo "window.location = 'index.php?do=81'; ";  // Redirect if there is an ongoing withdrawal
    echo "</script>";
} else {
    // Insert the withdrawal request into the database
    $sql = "INSERT INTO withdrawvip (id_vip, username_vip, phone_vip, bank_vip, bankacc_vip, name_vip, confirm_vip, amount_vip, note_vip)
            VALUES('$id_vip', '$username_vip', '$phone_vip', '$bank_vip', '$bankacc_vip', '$name_vip', '$confirm_vip', '$amount_vip', '$note_vip')";
    
    $result9 = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));

    if ($result9) {
        $usernameufa = $agent . $username_vip;
        $status = $api->add_credit($usernameufa, $amount_vip); 
        $status = json_decode($status);
        $status = $status->status;

        // If the API returns success (status code 200), update the withdrawal status
        if ($status == 200) {
            $sql7 = "UPDATE withdrawvip SET confirm_vip='อนุมัติ' WHERE phone_vip='$phone_vip' ORDER BY id DESC LIMIT 1";
            mysqli_query($con, $sql7) or die ("Error in query: $sql7 " . mysqli_error($con));

            // Send a notification to LINE
            $sMessage = "รับรางวัล VIP \nจำนวน " . $amount_vip . " บาท\nเบอร์ " . $phone_vip . " \nชื่อ " . $name_vip;
            $chOne = curl_init(); 
            curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0); 
            curl_setopt($chOne, CURLOPT_POST, 1); 
            curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage); 
            $headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key);
            curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
            curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1); 
            $result = curl_exec($chOne); 

            if (curl_error($chOne)) {
                echo 'error:' . curl_error($chOne); 
            } else {
                $result_ = json_decode($result, true);
            }
            curl_close($chOne);
        }

        // Close the database connection
        mysqli_close($con);

        // Redirect with success message
        header("Content-Type: text/html; charset=utf-8");
        echo "<script type='text/javascript'>";
        echo "window.location = 'index.php?do=80'; ";
        echo "</script>";
    } else {
        // Error handling for failed insertion
        mysqli_close($con);
        header("Content-Type: text/html; charset=utf-8");
        echo "<script type='text/javascript'>";
        echo "alert('Error back to withdrawvip again');";
        echo "</script>";
    }
}
?>
