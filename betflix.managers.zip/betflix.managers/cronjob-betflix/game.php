<?php
error_reporting(0);


function agentuser(){
    $agentuser='b42ppk88'; # ใส่ยุสเอเย่น
    return $agentuser;
} 
function api_betflix(){
    $api_betflix='JBREtz1aO6eGSHTl'; # ใส่ api-betflix
    return $api_betflix;
} 
function xapikey(){
    $api_betflix='89de9112d242dab79c06c734836cb76f'; # ใส่ api-key
    return $api_betflix;
}

function login($username=null){
  $username = $_GET['username'];

 $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://api.bfx.fail/v4/play/login',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => 'username='.$username,
          CURLOPT_HTTPHEADER => array(
          'x-api-betflix: '.api_betflix(),
          'x-api-key: '.xapikey(),
          'Content-Type: application/x-www-form-urlencoded'
          ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
 }
 $data2 = login($username);
$Balance1=json_decode($data2);
$Balance=$Balance1->data->login_token;
echo $Balance;

		
				//echo $balance;
				//window.location.replace("https://www.betflik.com/login/apilogin/".$token_login);
				header('Location: https://www.betflik.com/login/apilogin/'.$Balance);
?>
 