<?php
include('../config/connectdb.php');

// Fetch settings data once
$sql = "SELECT * FROM setting";
$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
$row = mysqli_fetch_array($result);
extract($row);

// Extract agent and set_wd variables
$key = $linewithdraw;
$agent = $row['agent'];
$setwd = $row['set_wd']; // Only fetch once

// Process the withdrawal request
$id_wd = $_POST["id_wd"];
$username_wd = $_POST["username_wd"];
$amount_wd = $_POST["amount_wd"];
$phone_wd = $_POST["phone_wd"];
$bank_wd = $_POST["bank_wd"];
$bankacc_wd = $_POST["bankacc_wd"];
$name_wd = $_POST["name_wd"];
$confirm_wd = $_POST["confirm_wd"];
$lastpro = $_POST["lastpro"];
$Balance2 = $_POST["creditufa"];
$aff_wd = $_POST["aff_wd"];

include('../cronjob-run/apiufa1062.php');

// Clean up Balance
$Balance3 = array(",");
$balance = str_replace($Balance3, "", $Balance);

// Fetch last deposit for checking withdrawal conditions
$sql = "SELECT * FROM deposit WHERE confirm_dp = 'อนุมัติ' AND phone_dp = '$phone_wd' ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
$row = mysqli_fetch_array($result);
$num77 = mysqli_num_rows($result);

extract($row);

// Process balance and conditions for withdrawal
$a = "$turnover"; // Turnover
$b = "0123456789";
$n = strlen($a);
$x = strlen($b);
$newstr = "";

for ($i = 0; $i <= $n; $i++) {
    for ($j = 0; $j <= $x; $j++) {
        if ($a[$i] == $b[$j]) {
            $newstr .= $b[$j];
        }
    }
}

// Validate withdrawal
if ($balance < $amount_wd) {
    redirectToPage(7);
} else if ($num77 < 1) {
    redirectToPage(7);
} else if ($balance == 'Total Bet Credit') {
    redirectToPage(8);
} else if ($balance < $newstr) {
    redirectToPage(9);
} else if ($amount_wd > $balance) {
    redirectToPage(10);
} else if ($amount_wd < $setwd) {
    redirectToPage(11);
} else {
    // Check if there is already an ongoing withdrawal
    $check = "SELECT username_wd FROM withdraw WHERE confirm_wd = 'รอดำเนินการ' AND id_wd = '$id_wd' ";
    $result1 = mysqli_query($con, $check) or die(mysqli_error());
    $num = mysqli_num_rows($result1);
    
    if ($num > 0) {
        redirectToPage(12);
    } else {
        $usernameufa = $agent . $username_wd;
        $status = $api->Withdraw($usernameufa, $amount_wd);
        $status = json_decode($status);
        $status = $status->status;

        if ($status == 200) {
            $sql9 = "INSERT INTO withdraw (id_wd, username_wd, phone_wd, bank_wd, bankacc_wd, name_wd, lastpro, add_wd, aff_wd)
                      VALUES ('$id_wd', '$username_wd', '$phone_wd', '$bank_wd', '$bankacc_wd', '$name_wd', '$lastpro', 'MEMBER', '$aff_wd')";
            $result9 = mysqli_query($con, $sql9) or die ("Error in query: $sql9 " . mysqli_error());

            if ($result9) {
                $sql7 = "UPDATE withdraw SET confirm_wd = 'รอดำเนินการ', pin_wd = 'unknown6134', amount_wd = '$amount_wd' 
                         WHERE phone_wd = '$phone_wd' AND amount_wd = '' ORDER BY id DESC LIMIT 1";
                $result7 = mysqli_query($con, $sql7) or die ("Error in query: $sql7 " . mysqli_error());

                // Notify via Line
                sendLineNotification($amount_wd, $phone_wd, $bankacc_wd, $bank_wd, $name_wd);
            }
        }
    }
}

function redirectToPage($pageNumber) {
    echo "<script>";
    echo "window.location = 'index.php?do=$pageNumber'; ";
    echo "</script>";
}

function sendLineNotification($amount_wd, $phone_wd, $bankacc_wd, $bank_wd, $name_wd) {
    global $key;
    $sMessage = "แจ้งถอนเงิน \nจำนวนเงิน $amount_wd บาท\nเบอร์ $phone_wd \nเลขบัญชี $bankacc_wd \nธนาคาร $bank_wd \nชื่อ $name_wd";
    $chOne = curl_init();
    curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
    curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($chOne, CURLOPT_POST, 1);
    curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
    $headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key);
    curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($chOne);
    if (curl_error($chOne)) {
        echo 'error:' . curl_error($chOne);
    } else {
        $result_ = json_decode($result, true);
    }
    curl_close($chOne);
}

mysqli_close($con);
?>

