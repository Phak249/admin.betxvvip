<?php
include('../config/connectdb.php');

// ตั้งค่า timezone
date_default_timezone_set('Asia/Bangkok');

// ฟังก์ชันตรวจสอบข้อมูลซ้ำ
function checkDuplicate($con, $query, $types, ...$params) {
    $stmt = $con->prepare($query);
    if (!$stmt) return false;
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

// ดึงค่าการตั้งค่า
$setting = [];
if ($stmt = $con->prepare("SELECT * FROM setting ORDER BY id DESC LIMIT 1")) {
    $stmt->execute();
    $result = $stmt->get_result();
    $setting = $result->fetch_assoc();
    $stmt->close();
}
$key = $setting['linedeposit'] ?? '';
$setdp = $setting['set_dp'] ?? '';

// รับข้อมูลจากฟอร์ม (พร้อม fallback ปลอดภัย)
$id_dp         = intval($_POST["id_dp"] ?? 0);
$username_dp   = trim($_POST["username_dp"] ?? '');
$amount_dp     = trim($_POST["amount_dp"] ?? '');
$phone_dp      = trim($_POST["phone_dp"] ?? '');
$bank_dp       = trim($_POST["bank_dp"] ?? '');
$bankacc_dp    = trim($_POST["bankacc_dp"] ?? '');
$name_dp       = trim($_POST["name_dp"] ?? '');
$promotion_dp  = trim($_POST["promotion_dp"] ?? '');
$aff_dp        = trim($_POST["aff_dp"] ?? '');
$note_dp       = trim($_POST["note_dp"] ?? '');
$bonus_dp      = trim($_POST["bonus_dp"] ?? '');
$fromTrue      = trim($_POST["fromTrue"] ?? '');
$game_dp       = trim($_POST["game_dp"] ?? ''); // เพิ่มไว้กรณีต้องใช้

$date_today = date("Y-m-d");

// ✅ ตรวจสอบว่ามีรายการรอดำเนินการแล้วหรือไม่
$query1 = "SELECT username_dp FROM deposit WHERE confirm_dp = 'รอดำเนินการ' AND id_dp = ? AND username_dp = ?";
if (checkDuplicate($con, $query1, "is", $id_dp, $username_dp)) {
    echo "<script>window.location = 'index.php?do=3';</script>";
    exit();
}

// ✅ ตรวจสอบโปรโมชั่นที่รับได้ครั้งเดียว
$query2 = "SELECT username_dp FROM deposit d JOIN promotion p ON d.promotion_dp = p.name_pro 
           WHERE username_dp = ? AND p.time_pro = 'รับได้ครั้งเดียว' AND promotion_dp = ? AND confirm_dp = 'อนุมัติ'";
if (checkDuplicate($con, $query2, "ss", $username_dp, $promotion_dp)) {
    echo "<script>window.location = 'index.php?do=4';</script>";
    exit();
}

// ✅ ตรวจสอบโปรโมชั่นประจำวันที่รับได้วันละครั้ง
$query3 = "SELECT username_dp FROM deposit d JOIN promotion p ON d.promotion_dp = p.name_pro 
           WHERE username_dp = ? AND promotion_dp = ? AND p.time_pro = 'รับได้วันละ 1 ครั้ง' 
           AND confirm_dp = 'อนุมัติ' AND DATE(date_dp) = ?";
if (checkDuplicate($con, $query3, "sss", $username_dp, $promotion_dp, $date_today)) {
    echo "<script>window.location = 'index.php?do=5';</script>";
    exit();
}

// ✅ เพิ่มรายการฝากใหม่
$insertQuery = "INSERT INTO deposit 
(id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, game_dp, fromTrue, add_dp) 
VALUES (?, ?, ?, ?, ?, ?, 'รอดำเนินการ', ?, ?, ?, ?, ?, ?, ?, 'MEMBER')";

$stmtInsert = $con->prepare($insertQuery);
if ($stmtInsert) {
    $stmtInsert->bind_param(
        "isssssssssssss",
        $id_dp,
        $username_dp,
        $phone_dp,
        $bank_dp,
        $bankacc_dp,
        $name_dp,
        $amount_dp,
        $promotion_dp,
        $aff_dp,
        $note_dp,
        $bonus_dp,
        $game_dp,
        $fromTrue
    );

    if ($stmtInsert->execute()) {
        echo "<script>window.location = 'index.php?do=6';</script>";
    } else {
        echo "<script>alert('เกิดข้อผิดพลาดขณะบันทึกข้อมูล กรุณาลองใหม่อีกครั้ง');</script>";
    }
    $stmtInsert->close();
} else {
    echo "<script>alert('ไม่สามารถเตรียมคำสั่ง SQL ได้');</script>";
}

$con->close();
?>
