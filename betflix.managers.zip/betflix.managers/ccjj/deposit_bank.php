<?php
require $_SERVER["DOCUMENT_ROOT"] . '/connectdb.php';
include $_SERVER["DOCUMENT_ROOT"] . '/class/betflix.php';
include $_SERVER["DOCUMENT_ROOT"] . '/class/scb.php';

$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1 ";
$res = $con->query($sql);
$row = $res->fetch_assoc();
extract($row);

//SCB Deposit
$scb = new Scb();
print_r($scb->getTransaction());