<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light set-width-topbar">
                        <!-- Left navbar links -->
                        <ul class="navbar-nav align-items-center">
                            <li class="nav-item">
                                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                                        class="fas fa-bars"></i></a>
                            </li>
                            <li class="nav-item">
                                <btn-refresh-dashboard />
                            </li>
                        </ul>

                        <!-- Right navbar links -->
                        <ul class="navbar-nav ml-auto">
                            <ul class="navbar-nav navbar-nav-right">

                                <div class="noti-list">
                                    <sms-badge />
                                </div>
                                <div class="noti-list">
                                    <router-link to="/commission">
                                        <div>

                                            <span
                                                class="badge badge-warning float-right topbar-pd-depo-with-sms DWbadge">
                                                <commission-badge />
                                            </span>
                                        </div>
                                        </a>
                                </div>
                                <div class="noti-list">
                                    <router-link to="/deposit">
                                        <div>
                                            <span
                                                class="badge badge-success float-right topbar-pd-depo-with-sms DWbadge">
                                                <depo-badge />
                                            </span>
                                        </div>
                                        </a>
                                </div>
                                <div class="noti-list">
                                    <router-link to="/withdraw">
                                        <div>
                                            <span
                                                class="badge badge-danger float-right topbar-pd-depo-with-sms DWbadge">
                                                <draw-badge />
                                            </span>
                                        </div>
                                        </a>
                                </div>
                                <div class="border-right h-100 d-flex align-items-center p-2 power-off-div">
                                    <power-off-server />
                                </div>
                                <div class="btn-group pl-2 border-right">
                                    <li class="dropdown" style="align-self: center;">
                                        <a class="mr-navbar-tablet nav-link lang_select" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            <img src="img/th.png" class="lang_flag" />
                                            <span class="icon-caret caret_icon"></span>
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-right lang_dropdown animate slideIn">


                                            <li class="thai lang_active">
                                                <img src="img/th.png" class="lang_flag" /><span
                                                    class="lang_text">TH</span>
                                            </li>
                                            <li class="eng ">
                                                <img src="img/en.png" class="lang_flag" /><span
                                                    class="lang_text">EN</span>
                                            </li>
                                        </ul>
                                    </li>
                                </div>
                                <div class="border-right topbar-admin-padding">
                                    <div class="description-block status-web-admin-margin width-username-role">
                                        <profile-topbar />
                                    </div>
                                </div>
                                <div class="row ">
                                    <div>
                                        <sms-topbar />
                                    </div>
                                    <div class="border-right show-tablet-logout">
                                        <div class="description-block status-web-admin-margin" style="width: 75px;">
                                            ออนไลน์
                                            <div>
                                                <online-customer />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="border-right show-tablet-logout">
                                        <div class="description-block status-web-admin-margin" style="width: 75px;">
                                            ฝาก
                                            <div>
                                                <depo-auto />
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col -->
                                    <div class="border-right show-tablet-logout">
                                        <div class="description-block status-web-admin-margin" style="width: 75px;">
                                            ถอน
                                            <div>
                                                <draw-auto />
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col -->
                                    <div class="border-right show-tablet-logout">
                                        <div class="description-block status-web-admin-margin" style="width: 75px;">
                                            เว็บ
                                            <div>
                                                <web-status />
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col -->
                                    <div class="border-right  show-tablet-logout">
                                        <div class="description-block status-web-admin-margin" style="width: 75px;">
                                            ถอน
                                            <div>
                                                <draw-status />
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <div style="margin-right:2.1em"></div>



                                <a class="show-tablet-logout" style="color: white;padding-top: 12px;" href="/logout"
                                    onclick="event.preventDefault();
                                                                                                                                                                                                                                                                                        document.getElementById('logout-form').submit();"
                                    class="nav-link">
                                    <i class="fa fa-sign-out-alt"></i>
                                </a>
                                <form id="logout-form" action="/logout" method="POST" style="display: none;">
                                    <input type="hidden" name="_token" value="O1wY7T92ZOQFjaJvkiGNqH0wqZO8SgQUI6UKjpgq">
                                </form>
                                <!-- </button> -->
                                <div class="btn-group">
                                    <a class="d-sm-inline-block show-phone-dropdown-profile" href="#"
                                        data-toggle="dropdown">
                                        <img class="img-circle elevation-2" src="img/websetting/1694071567.png"
                                            alt="Chris Wood" width="40" height="40" style="border: 1px solid #ffffff;">
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right animate slideIn width-dropdown-admin-phone"
                                        style="left: auto;
                                                                                                                                                                                                                                                                                            margin-top: 0.8em;
                                                                                                                                                                                                                                                                                            right: 0.3em;
                                                                                                                                                                                                                                                                                            background: #ffffff;
                                                                                                                                                                                                                                                                                            color: black !important;
                                                                                                                                                                                                                                                                                            height: auto;
                                                                                                                                                                                                                                                                                            transition: 0.4s;
                                                                                                                                                                                                                                                                                        ">
                                        <div style="padding-left:1rem;padding-right:1rem;">
                                            <div class="card card-widget widget-user "
                                                style="box-shadow: 0px 0px 0px #868686;border-radius: 0px 0px 0px 0px;">
                                                <div class="widget-user-header bg-info"
                                                    style="background-color:#ffffff !important;border-top-left-radius: 0rem !important;
                                                                                                                                                                                                                                                                            border-top-right-radius: 0rem !important;height: 52px !important;">
                                                </div>
                                                <div class="widget-user-image" style="top: 10px !important;">
                                                    <img class="img-circle elevation-2"
                                                        src="img/websetting/1694071567.png" alt="User Avatar">
                                                </div>
                                                <div class="card-footer"
                                                    style="background-color:#ffffff;padding-top: 60px !important;border-top: none;padding-bottom: 0;padding-left: 0px;
                                                                                                                                                                                                                                                                                                padding-right: 0px;">
                                                    <div style="text-align:center">
                                                        <router-link to="/profile" class="color-font-router">
                                                            <h4 class="widget-user-username" style="font-size: 15px;">
                                                                EAK
                                                            </h4>
                                                            <h5 class="widget-user-desc" style="font-size: 15px;">
                                                                ผู้จัดการ
                                                            </h5>
                                                            </a>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-4 border-right" style="padding: 0px;">
                                                            <div class="description-block ">
                                                                <div style="font-size: 12px;"
                                                                    class="description-header">
                                                                    ออนไลน์
                                                                </div>
                                                                <div>
                                                                    <online-customer />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-4 border-right" style="padding: 0px;">
                                                            <div class="description-block">
                                                                <div style="font-size: 12px;"
                                                                    class="description-header">
                                                                    ฝาก
                                                                </div>
                                                                <div>
                                                                    <depo-auto />
                                                                </div>
                                                            </div>
                                                            <!-- /.description-block -->
                                                        </div>
                                                        <!-- /.col -->
                                                        <div class="col-4 border-right" style="padding: 0px;">
                                                            <div class="description-block">
                                                                <div style="font-size: 12px;"
                                                                    class="description-header">
                                                                    ถอน
                                                                </div>
                                                                <div>
                                                                    <draw-auto />
                                                                </div>
                                                            </div>
                                                            <!-- /.description-block -->
                                                        </div>
                                                        <!-- /.col -->
                                                        <div class="col-4 border-right" style="padding: 0px;">
                                                            <div class="description-block">
                                                                <div style="font-size: 12px;"
                                                                    class="description-header">
                                                                    เว็บ
                                                                </div>
                                                                <div>
                                                                    <web-status-mobile />
                                                                </div>
                                                            </div>
                                                            <!-- /.description-block -->
                                                        </div>
                                                        <div class="col-4 border-right" style="padding: 0px;">
                                                            <div class="description-block">
                                                                <div style="font-size: 12px;"
                                                                    class="description-header">
                                                                    ถอน
                                                                </div>
                                                                <div>
                                                                    <draw-status-mobile />
                                                                </div>
                                                            </div>
                                                            <!-- /.description-block -->
                                                        </div>
                                                        <!-- /.col -->
                                                    </div>
                                                    <div class="col-4 border-right" style="padding: 0px;">

                                                        <div class="border-right h-100 d-flex align-items-end p-2">
                                                            <power-off-server />
                                                        </div>
                                                        <!-- /.description-block -->
                                                    </div>
                                                    <!-- /.col -->
                                                </div>
                                            </div>
                                            <!-- /.widget-user -->
                                        </div>


                                        <div class="dropdown-divider"></div>
                                        <div style="width:100%;padding:1rem">
                                            <button type="button" class="button-position-change">
                                                <a style="color: white" href="/logout"
                                                    onclick="event.preventDefault();
                                                                                                                                                                                                                                                                                        document.getElementById('logout_form').submit();"
                                                    class="nav-link">
                                                    ออกจากระบบ <i class="fa fa-sign-out-alt"></i>
                                                </a>
                                                <form id="logout_form" action="/logout" method="POST"
                                                    style="display: none;">
                                                    <input type="hidden" name="_token"
                                                        value="O1wY7T92ZOQFjaJvkiGNqH0wqZO8SgQUI6UKjpgq">
                                                </form>
                                            </button>
                                        </div>
                                    </div>
                            </ul>
                            <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center"
                                type="button" data-toggle="offcanvas">
                                <span class="icon-menu"></span>
                            </button>

                        </ul>
                    </nav>
                    <!-- /.navbar -->
