<?php
include('../config/connectdb.php');

// ฟังก์ชันสำหรับตรวจสอบการซ้ำ
function checkDuplicate($con, $column, $value, $extra = '') {
    $sql = "SELECT $column FROM deposit WHERE $column = ? $extra";
    $stmt = $con->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("s", $value);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

// ฟังก์ชัน redirect
function redirectTo($url) {
    echo "<script>window.location = '$url';</script>";
    exit();
}

// ดึงการตั้งค่าและกิจกรรมล่าสุด
$setting = [];
$activity = [];
if ($stmt = $con->prepare("SELECT * FROM setting ORDER BY id DESC LIMIT 1")) {
    $stmt->execute();
    $result = $stmt->get_result();
    $setting = $result->fetch_assoc();
    $stmt->close();
}
$key = $setting['linedeposit'] ?? '';
$setdp = $setting['set_dp'] ?? '';

if ($stmt = $con->prepare("SELECT * FROM activity ORDER BY id DESC LIMIT 1")) {
    $stmt->execute();
    $result = $stmt->get_result();
    $activity = $result->fetch_assoc();
    $stmt->close();
}
$amount = $activity['credit_at'] ?? 0;
$status_at = $activity['status_at'] ?? 'ปิด';

if ($status_at !== 'เปิด') {
    redirectTo('index.php?do=14');
}

// รับข้อมูลจากฟอร์มแบบปลอดภัย
$id_dp         = isset($_POST["id_dp"]) ? intval($_POST["id_dp"]) : 0;
$username_dp   = trim($_POST["username_dp"] ?? '');
$amount_dp     = trim($_POST["amount_dp"] ?? '');
$phone_dp      = trim($_POST["phone_dp"] ?? '');
$bank_dp       = trim($_POST["bank_dp"] ?? '');
$bankacc_dp    = trim($_POST["bankacc_dp"] ?? '');
$name_dp       = trim($_POST["name_dp"] ?? '');
$confirm_dp    = 'รอดำเนินการ'; // ใช้ค่าคงที่
$promotion_dp  = trim($_POST["promotion_dp"] ?? '');
$aff_dp        = trim($_POST["aff_dp"] ?? '');
$note_dp       = trim($_POST["note_dp"] ?? '');
$bonus_dp      = trim($_POST["bonus_dp"] ?? '');
$turnover      = trim($_POST["turnover"] ?? '');
$bankin_dp     = trim($_POST["bankin_dp"] ?? '');
$ip_dp         = trim($_POST["ip_dp"] ?? '');

// เช็คข้อมูลซ้ำ
if (checkDuplicate($con, 'phone_dp', $phone_dp, "AND promotion_dp = '$promotion_dp' AND amount_dp = 'กิจกรรม' AND confirm_dp = 'อนุมัติ'")) {
    redirectTo('index.php?do=15');
}
if (checkDuplicate($con, 'ip_dp', $ip_dp, "AND promotion_dp = '$promotion_dp' AND amount_dp = 'กิจกรรม'")) {
    redirectTo('index.php?do=16');
}
if (checkDuplicate($con, 'username_dp', $username_dp, "AND confirm_dp = 'รอดำเนินการ' AND id_dp = $id_dp")) {
    redirectTo('index.php?do=3');
}

// เพิ่มรายการฝาก
$sql = "INSERT INTO deposit 
        (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, turnover, bankin_dp, ip_dp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $con->prepare($sql);
if ($stmt) {
    $stmt->bind_param(
        "issssssssssssss",
        $id_dp,
        $username_dp,
        $phone_dp,
        $bank_dp,
        $bankacc_dp,
        $name_dp,
        $confirm_dp,
        $amount_dp,
        $promotion_dp,
        $aff_dp,
        $note_dp,
        $bonus_dp,
        $turnover,
        $bankin_dp,
        $ip_dp
    );

    if ($stmt->execute()) {
        redirectTo('index.php?do=17');
    } else {
        echo "<script>alert('เกิดข้อผิดพลาดในการบันทึกข้อมูล');</script>";
    }
    $stmt->close();
} else {
    echo "<script>alert('เตรียมคำสั่ง SQL ไม่สำเร็จ');</script>";
}

$con->close();
?>
