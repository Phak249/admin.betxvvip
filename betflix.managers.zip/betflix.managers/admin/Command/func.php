<?php 
define( 'ROOTPATH', $_SERVER["DOCUMENT_ROOT"] . '/' );
?>
