<?php include '../inc/header2.php'; ?>
<?php include '../Command/body_report.php'; ?>
<?php include '../inc/footer.php'; ?>