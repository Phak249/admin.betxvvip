<?php
include('../config/connectdb.php'); 

// รับค่าจากฟอร์ม
$phone_mb = $_POST["phone_mb"];
$old_password = $_POST["password_mb"];    // รหัสผ่านเดิม
$new_password = $_POST["newpass"];        // รหัสผ่านใหม่
$new_password_confirm = $_POST["newpass2"]; // ยืนยันรหัสผ่านใหม่

// ตรวจสอบว่ามีผู้ใช้ที่ตรงกับเบอร์โทรศัพท์และรหัสผ่านเดิมหรือไม่
$sql = "SELECT * FROM member WHERE phone_mb='$phone_mb' AND password_mb='$old_password'";
$result = mysqli_query($con, $sql);
$num = mysqli_num_rows($result);

if ($num != 1) {
    echo "<script>";
    echo "alert('ข้อมูลไม่ถูกต้อง หรือรหัสผ่านเดิมไม่ถูกต้อง!');";
    echo "window.location = 'login.php';";
    echo "</script>";
    exit();
}

// ตรวจสอบว่ารหัสผ่านใหม่และการยืนยันตรงกันหรือไม่
if ($new_password !== $new_password_confirm) {
    echo "<script>";
    echo "alert('รหัสผ่านใหม่และการยืนยันไม่ตรงกัน!');";
    echo "window.location = 'login.php';";
    echo "</script>";
    exit();
}

// อัปเดตรหัสผ่านใหม่
$sql_update = "UPDATE member SET password_mb='$new_password' WHERE phone_mb='$phone_mb'";
$result_update = mysqli_query($con, $sql_update) or die("Error in query: $sql_update " . mysqli_error($con));

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);

// แสดงผลลัพธ์
if ($result_update) {
    echo "<script type='text/javascript'>";
    echo "alert('เปลี่ยนรหัสผ่านสำเร็จ');";
    echo "window.location = 'login.php';";
    echo "</script>";
} else {
    echo "<script type='text/javascript'>";
    echo "alert('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');";
    echo "</script>";
}
?>
