<?php include '../inc/header.php'; ?>
<?php include '../Command/body_withdraw.php'; ?>
<?php include '../inc/footer.php'; ?>