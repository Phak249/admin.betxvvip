<?php include '../inc/header.php'; ?>
<?php include '../Command/body_spin_history.php'; ?>
<?php include '../inc/footer.php'; ?>