<meta charset="UTF-8">
<?php
session_start();
include('../../config/connectdb.php');


$id_ad = $_SESSION['id_ad'];
$name_ad = $_SESSION['name_ad'];
$username_ad = $_SESSION['username_ad'];
$status_ad = $_SESSION['status_ad'];

if ($status_ad == '') {

	Header("Location: login.php");
}


$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1 ";
$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error());
$row = mysqli_fetch_array($result);
extract($row);
$logo = $logo_web;
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/png" href="/src/assets/img/websetting/1694071567.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ระบบจัดการแดชบอร์ด</title>
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/57ecf8f9f9.js" crossorigin="anonymous"></script>
    <!-- Google Fonts - Thai -->
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600&family=Prompt:wght@300;400;500;600&family=Sarabun:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="../assets/css/app.css" rel="stylesheet">
  </head>
<body>
<div id="app">
  
    <main >
	<body class="hold-transition sidebar-mini">
      <div class="wrapper"id="app">
        <!-- Navbar -->
		<?php include '../inc/navbar.php'; ?>
		<!-- Sidebar -->
		<?php include '../inc/sidebar.php'; ?>
	<div class="content-wrapper set-height-content" style="background:#e7e7e7;padding-top:4.7em">
	