<?php
error_reporting(1);
require $_SERVER["DOCUMENT_ROOT"] . '/connectdb.php';
include $_SERVER["DOCUMENT_ROOT"] . '/class/betflix.php';
include $_SERVER["DOCUMENT_ROOT"] . '/class/scb.php';

$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1 ";
$res = $con->query($sql);
$row = $res->fetch_assoc();
extract($row);

//SCB
$scb = new Scb();

if ($scb->status) {
	
	$scbbb = json_decode($scb->GetBalance())->result;

	$sql = "UPDATE `credit` SET `credit_scb` = '$scbbb' WHERE `credit`.`id` = 1";
	$res = $con->query($sql);
	$transection = json_decode($scb->getTransaction())->result;
	$sql_insert_reportscb = 'INSERT INTO reportscb(type, amount, details, date_check, time_check) VALUES';
	$api = new Betflix();
	foreach ($transection as $value) {
		$txnCode = $value->txnCode->description; //รายการ
		$txnDateTime = $value->txnDateTime; //เวลา
		$deposit = $value->txnAmount; //ยอดเงิน
		$txnRemark = $value->txnRemark; //เลขบัญชี
		$name = $value->txnRemark; //ชื่อ
		//echo $txnCode;
		//echo $deposit;

		preg_match('/SCB/', $txnRemark, $output_array);
		$check = $output_array[0];
		$check_bank = $output_array[0];
		if ($check == "SCB") {
			preg_match_all('/(?<=x)(.*?)(?= )/', $txnRemark, $output_array);
			$fromAccount = $output_array[0][0];
			$naem_cut = explode(" ", $name);
			$name = 'ไทยพาณิชย์';
			$namescb = $naem_cut[4];
			$turn2 = $deposit * 2;
		} else {
			preg_match_all('/(?<=X).+/', $txnRemark, $output_array);
			$fromAccount = $output_array[0][0];
			preg_match('/.(.*?)(?= )/', $name, $output_array);
			$name = $output_array[0];
		}
		// echo $name;
		// echo $deposit;


		preg_match('/(.*?)(?=T)/', $txnDateTime, $output_array);
		$date = date_create($output_array[0]);
		$date_check = date_format($date, "Y-m-d");

		preg_match('/(?<=T).(.*?)(?=\+)/', $txnDateTime, $output_array);
		$time_check = $output_array[0];

		$checkdp = "SELECT id FROM reportscb WHERE date_check='$date_check' AND time_check='$time_check'";
		$query12 = $con->query($checkdp);
		$num = $query12->num_rows;

		if ($num == 0) {
			$sql_insert_reportscb .= "('$txnCode', '$deposit',  '$txnRemark',  '$date_check',  '$time_check'),";
		}
	}

	if ($sql_insert_reportscb != 'INSERT INTO reportscb(type, amount, details, date_check, time_check) VALUES') {
		$sql_insert_reportscb = rtrim($sql_insert_reportscb, ",") . ";";
		$result = $con->query($sql_insert_reportscb) or die("Error in query: $con ");
	}

	$sql = "SELECT * FROM reportscb ORDER BY id DESC LIMIT 100";
	$res = $con->query($sql);
	if ($res->num_rows > 0) {
		echo '<pre>';
		$resultset = array();
		while ($row = $res->fetch_object()) {
			$resultset[] = $row;
		}
		foreach ($resultset as $row) {
			$txnCode = $row->type;
			$date_check = $row->date_check;
			$time_check = $row->time_check;
			$txnRemark = $row->details;
			$name = $txnRemark;
			$deposit = $row->amount;
			preg_match('/SCB/', $txnRemark, $output_array);
			$check = $output_array[0];
			$check_bank = $output_array[0];
			if ($check == "SCB") {
				preg_match_all('/(?<=x)(.*?)(?= )/', $txnRemark, $output_array);
				$fromAccount = $output_array[0][0];
				$naem_cut = explode(" ", $name);
				$name = 'ไทยพาณิชย์';
				$namescb = $naem_cut[4];
				$turn2 = $deposit * 2;
			} else {
				preg_match_all('/(?<=X).+/', $txnRemark, $output_array);
				$fromAccount = $output_array[0][0];
				preg_match('/.(.*?)(?= )/', $name, $output_array);
				$name = $output_array[0];
			}

			if ($txnCode == "ฝากเงิน" || $txnCode == "Deposit") {
				$sql_checkdp = "SELECT * FROM deposit WHERE date_check='$date_check' AND time_check='$time_check' AND fromAccount = '$fromAccount'";
				$query2 = $con->query($sql_checkdp) or die("Error in query: $con ");
				$num = $query2->num_rows;


				if ($num == 0) {
					$sql_check = "SELECT * FROM deposit WHERE bankacc_dp LIKE '%$fromAccount%' AND confirm_dp='รอดำเนินการ' ORDER BY id DESC LIMIT 1";
					$query = $con->query($sql_check) or die("Error in query: $con ");
					$row_pro = $query->fetch_assoc();
					$check = $query->num_rows;



					//echo $check;
					if ($check == 1) {
						echo '<br>111111';
						echo $check;
						echo '<br>';
						extract($row_pro);
						$get_pro = $promotion_dp;
						$username = $username_dp;
						$phone_dp = $phone_dp;
						$sql_promotion = "SELECT * FROM promotion WHERE name_pro='$get_pro'";
						$query = $con->query($sql_promotion) or die("Error in query: $con ");
						$row7 = $result7->fetch_assoc();
						extract($row7);
						$money = $dp_pro;
						$namepro = $name_pro;
						$bonusper_pro = $bonusper_pro;
						$dp_pro = $dp_pro;
						$turn = $turn_pro;
						$max_pro = $max_pro;
						//echo $max_pro;
						function extract_int($str)
						{
							preg_match('/[^0-9]*([0-9]+)[^0-9]*/', $str, $regs);
							return (intval($regs[1]));
						}
						$a = $turn;
						$turnover1 = extract_int($a);

						$bonus_pro1 = $bonus_pro + ($deposit * $bonusper_pro / 100);

						if ($bonus_pro1 > $max_pro) {
							$bonus_pro = $max_pro;
						} else {
							$bonus_pro = $bonus_pro + ($deposit * $bonusper_pro / 100);
						}



						//echo $bonus_pro;
						if ($bonusper_pro != 0) {
							$turn_pro = ($deposit + $bonus_pro) * $turnover1;
						} else {
							$turn_pro = $turnover1;
						}
						//echo $turn_pro;

						if ($get_pro == $namepro and $deposit >= $money) {
							$sum = $deposit + $bonus_pro;
						} else {
							$sum = $deposit;
						}

						//echo $sum;
						$usernameufa = $agent . $username;
						//echo $usernameufa;
						$data = $api->deposit($usernameufa, $sum);
						$key = $linedeposit;
						if (!$data->error_code and $get_pro == $namepro and $deposit >= $money) {
							$sql7 = "UPDATE deposit SET  
									confirm_dp='อนุมัติ' , 
									amount_dp='$deposit' ,
									bonus_dp='$bonus_pro' ,
									bankin_dp = 'ธนาคารไทยพาณิชย์' ,
									date_check ='$date_check' ,
									time_check = '$time_check' ,
									turnover = '$turn_pro' ,
									fromAccount = '$fromAccount'
									WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
							echo "Update sql7" . $sql7."<br>";
							$result7 = mysqli_query($con, $sql7) or die("Error in query: $sql ");

							if ($result7 == true) {


								$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_dp . "\nโปรโมชั่น " . $get_pro;
								$chOne = curl_init();
								curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
								curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
								curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
								curl_setopt($chOne, CURLOPT_POST, 1);
								curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
								$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
								curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
								curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
								$result = curl_exec($chOne);
								if (curl_error($chOne)) {
									echo 'error:' . curl_error($chOne);
								} else {
									$result_ = json_decode($result, true);
								}
								curl_close($chOne);
							}
						} elseif ($status == 'success') {

							$sql = "UPDATE deposit SET  
									confirm_dp ='อนุมัติ' , 
									amount_dp ='$deposit' ,
									bonus_dp = 0 ,
									bankin_dp = 'ธนาคารไทยพาณิชย์' ,
									date_check ='$date_check' ,
									time_check = '$time_check' ,
									promotion_dp = 'ไม่รับโบนัส' ,
									turnover = '$turn2' ,
									fromAccount = '$fromAccount'
									WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
									echo "Update sql" . $sql."<br>";
							$result = mysqli_query($con, $sql) or die("Error in query: $sql ");

							$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_dp . "\n" . "ไม่รับโบนัส";
							$chOne = curl_init();
							curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
							curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
							curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
							curl_setopt($chOne, CURLOPT_POST, 1);
							curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
							$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
							curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
							curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
							$result = curl_exec($chOne);
							if (curl_error($chOne)) {
								echo 'error:' . curl_error($chOne);
							} else {
								$result_ = json_decode($result, true);
							}
							curl_close($chOne);
						}
						//echo $sum;

					} else {
						echo "If name :" . $name . "<br>";
						echo "If fromAccount :" . $fromAccount . "<br>";
						if ($name == 'ไทยพาณิชย์') {

							//echo $name;

							$sql_topup = "SELECT * FROM member WHERE bankacc_mb LIKE '%$fromAccount%' AND bank_mb ='ธ.ไทยพาณิชย์'";
							$result7 = mysqli_query($con, $sql_topup);

							while ($row7 = mysqli_fetch_array($result7)) {
								$username = $row7['username_mb'];
								$id_mb = $row7['id_mb'];
								$fromTrue = $row7['	phone_true'];
								$phone_mb = $row7['phone_mb'];
								$bank_mb = $row7['bank_mb'];
								$bankacc_mb2 = $row7['bankacc_mb'];
								$name_mb = $row7['name_mb'];
								$aff = $row7['aff'];
								//echo $username;
								$usernameufa = $agent . $username;

								$bankacc_mb = substr($bankacc_mb2, 6);
								// echo $bankacc_mb;
								// echo '<br>';

								// echo $fromAccount;
								// echo '<br>';

								if ($fromAccount == $bankacc_mb) {
									//echo $name_mb;
									//echo $usernameufa;
									$data = $api->deposit($usernameufa, $deposit);
									if (!$data->error_code) {

										$sql8 = "INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, fromTrue, date_check, time_check, bankin_dp, fromAccount, turnover)
												VALUES('$id_mb', '$username', '$phone_mb', '$bank_mb', '$bankacc_mb','$name_mb', 'อนุมัติ', '$deposit', 'ไม่รับโบนัส', '$aff', '', '0', '$fromTrue', '$date_check', '$time_check', 'ธนาคารไทยพาณิชย์', '$fromAccount', 0)";
										echo "Update sql8" . $sql8."<br>";
										$result = mysqli_query($con, $sql8) or die("Error in query: $con ");


										$key = $linedeposit;



										$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_mb . "\n" . "ไม่รับโบนัส";
										$chOne = curl_init();
										curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
										curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
										curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
										curl_setopt($chOne, CURLOPT_POST, 1);
										curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
										$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
										curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
										$result = curl_exec($chOne);
										if (curl_error($chOne)) {
											echo 'error:' . curl_error($chOne);
										} else {
											$result_ = json_decode($result, true);
										}
										curl_close($chOne);
									}
								}
							}
						} else {
							$sql_topup = "SELECT * FROM member WHERE bankacc_mb LIKE '%$fromAccount%'";
							$result7 = mysqli_query($con, $sql_topup);

							while ($row7 = mysqli_fetch_array($result7)) {
								$username = $row7['username_mb'];
								$id_mb = $row7['id_mb'];
								$fromTrue = $row7['	phone_true'];
								$phone_mb = $row7['phone_mb'];
								$bank_mb = $row7['bank_mb'];
								$bankacc_mb2 = $row7['bankacc_mb'];
								$name_mb = $row7['name_mb'];
								$aff = $row7['aff'];

								$usernameufa = $agent . $username;

								//echo $name;
								if ($name == 'ออมสิน') {
									$bankacc_mb = substr($bankacc_mb2, 6);
								} elseif ($name == 'ธกส.') {
									$bankacc_mb = substr($bankacc_mb2, 6);
								} else {
									$bankacc_mb = substr($bankacc_mb2, 4);
								}
								// echo $bankacc_mb;
								// echo '<br>';

								// echo $fromAccount;
								// echo '<br>';

								if ($fromAccount == $bankacc_mb) {
									//echo $username;



									$data= $api->deposit($usernameufa, $deposit);
									echo '<br>';
									print_r($data);
									echo '<br>';
									if (!$data->error_code) {

										$sql9 = "INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, fromTrue, date_check, time_check, bankin_dp, fromAccount, turnover)
												VALUES('$id_mb', '$username', '$phone_mb', '$bank_mb', '$bankacc_mb','$name_mb', 'อนุมัติ', '$deposit', 'ไม่รับโบนัส', '$aff', '', '0', '$fromTrue', '$date_check', '$time_check', 'ธนาคารไทยพาณิชย์', '$fromAccount', 0)";
										echo "Update sql9" . $sql9."<br>";
										
										$result = mysqli_query($con, $sql9) or die("Error in query: $con ");

										$key = $linedeposit;



										$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_mb . "\n" . "ไม่รับโบนัส";
										$chOne = curl_init();
										curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
										curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
										curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
										curl_setopt($chOne, CURLOPT_POST, 1);
										curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
										$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
										curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
										$result = curl_exec($chOne);
										if (curl_error($chOne)) {
											echo 'error:' . curl_error($chOne);
										} else {
											$result_ = json_decode($result, true);
										}
										curl_close($chOne);
									}
								}
							}
						}
					}
				} else {
					echo "no update";
					print "<br>";
				}
			}
		}
	}
} else {
	exit(json_encode(['status' => false, 'msg' => 'SCB Close']));
}
