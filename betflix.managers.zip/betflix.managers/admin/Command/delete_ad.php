
<?php
include ('../config/connectdb.php');
$id_ad = $_REQUEST["id_ad"];

//ลบข้อมูลออกจาก database ตาม id_mb ที่ส่งมา

$sql = "DELETE FROM admin WHERE id_ad='$id_ad' ";
$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());

//จาวาสคริปแสดงข้อความเมื่อบันทึกเสร็จและกระโดดกลับไปหน้าฟอร์ม
	
	if($result){
	echo "<script type='text/javascript'>";
	echo "alert('delete Succesfuly');";
	echo "window.location = 'staff.php'; ";
	echo "</script>";
	}
	else{
	echo "<script type='text/javascript'>";
	echo "alert('Error back to delete again');";
	echo "</script>";
}
?>