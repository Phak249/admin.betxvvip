<?php
include('../config/connectdb.php');

// ดึงข้อมูลการตั้งค่าล่าสุด
$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));
$row = mysqli_fetch_array($result);

extract($row);
$key = $linewithdraw;

// รับค่าจากฟอร์ม
$id = $_POST["id"];
$username = $_POST["username"];
$phone = $_POST["phone"];

// ตรวจสอบข้อมูลสมาชิก
$sqlchk = "SELECT * FROM member WHERE username_mb='$username'";
$resultchk = mysqli_query($con, $sqlchk) or die("Error in query: $sqlchk " . mysqli_error($con));
$rowchk = mysqli_fetch_array($resultchk);

$point = $rowchk['point'];
$total1 = $point * $change_point;

if ($point <= 0) {
    echo "<script>";
    echo "window.location = 'index.php?do=72'; ";
    echo "</script>";
    exit;
}

include('../cronjob-run/apiufa1062.php');
$usernameufa = $agent . $username;
$response = $api->add_credit($usernameufa, $total1);
$response = json_decode($response);

$status = $response->status ?? null;

if ($status == 200) {
    $update5 = "UPDATE member SET point = 0 WHERE username_mb = '$username'";
    $result59 = mysqli_query($con, $update5) or die("Error in query: $update5 " . mysqli_error($con));

    $sql9 = "INSERT INTO changepoint (id_change, username, amount, confirm_change)
             VALUES('$id', '$username', '$point', 'อนุมัติ')";
    $result9 = mysqli_query($con, $sql9) or die("Error in query: $sql9 " . mysqli_error($con));
    
    // ส่ง LINE Notify
    $sMessage = "แลกรางวัล \nจำนวนพ้อยด์ $point \nเบอร์ $phone";
    $chOne = curl_init(); 
    curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
    curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0); 
    curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0); 
    curl_setopt($chOne, CURLOPT_POST, 1); 
    curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
    $headers = [
        'Content-type: application/x-www-form-urlencoded',
        'Authorization: Bearer '.$key
    ];
    curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
    curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1); 
    $result = curl_exec($chOne); 
    if (curl_error($chOne)) {
        echo 'Curl error: ' . curl_error($chOne);
    }
    curl_close($chOne);
}

// ปิดการเชื่อมต่อ
mysqli_close($con);

// แจ้งผลการทำงาน
header("Content-Type: text/html; charset=utf-8");
echo "<script type='text/javascript'>";
if (isset($result9) && $result9) {
    echo "window.location = 'index.php?do=71'; ";
} else {
    echo "alert('Error back to withdraw again');";
}
echo "</script>";
?>
