module.exports = {
    stateFile: 'data.json',
    accountNo: '0093809149',
    accountType: 'SA',
    pin: '145211',
};