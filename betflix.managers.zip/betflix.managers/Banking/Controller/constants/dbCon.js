module.exports = con = {
    host: '149.28.139.232',
    user: "qrcode_project",
    password: "xZ8pPDNZHHNspc6m",
    database: "qrcode_project"
};