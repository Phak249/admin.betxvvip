
<?php
 //error_reporting(0);

require '../connectdb.php';

require'../kbank525698/kplus.Class.php';


$sql = "SELECT * FROM bank WHERE name_bank='ธนาคารกสิกรไทย'";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$endpoint = $row['token_kbank'];



$api2 = new Kplus($endpoint);
$data = json_encode($api2->getBalance(),JSON_UNESCAPED_UNICODE);
$balance=json_decode($data);
$balanceKbank=$balance->outstandingBalance;



//echo $balanceKbank;
if ($balanceKbank!='') {
  echo 'ดึงรายการ Kbank สำเร็จ';
}else{
  echo 'เช็ค Kbank ด่วน!!!';
}


$data3 = json_encode($api2->getTransactions());
$balance4=json_decode($data3);


foreach ($balance4->activityList as $v) {//แตกรายการ kbank

$code_dp = $v->rqUid;

$deposit = $v->amount;
$transactionDescription2 = $v->transactionDescription;
$transactionDescription = $v->transactionType;
//$fromAccount1 = $v->fromAccountNo;
$kplus = $v->channel;
$toacc = $v->toAccountNo;

$json = json_encode($api2->getTransactionDetail($code_dp));
$balance2=json_decode($json);
$fromAccount4 = $balance2->fromAccountNo;
$fromAccountName3 = $balance2->fromBankName;
$toBankName = $balance2->toBankName;
$toname = $balance2->toAccountName;
$fromname = $balance2->fromAccountName;

if ($fromAccountName3=='ธ.ทหารไทยธนชาต') {
  $fromAccountName='ธ.ทหารไทยธนชาติ';
}else{
  $fromAccountName=$fromAccountName3;
}
 
//echo $toBankName;
if ($kplus=='K PLUS') {
  $fromAccount1 = $v->fromAccountNo;
}elseif($kplus=='LINE BK') {
  $fromAccount1 = $v->fromAccountNo;
}elseif($kplus=='K PLUS SME') {
  $fromAccount1 = $v->fromAccountNo;
}elseif($kplus=='K-Cash Connect Plus') {
  $fromAccount1 = $v->fromAccountNo;
}else{
  $fromAccount1 = $balance2->fromAccountNo;
}




if ($kplus=='K PLUS') {
  $fromName = $v->fromAccountName;
}elseif($kplus=='LINE BK') {
  $fromName = $v->fromAccountName;
}elseif($kplus=='K PLUS SME') {
  $fromName = $v->fromAccountName;
}else{
  $fromName = $balance2->fromAccountName;
}


$vowels2 = array("-", "x");
$fromAccount = str_replace($vowels2, "", $fromAccount1);




  $checkdp = "SELECT id FROM reportkbank WHERE code='$code_dp'";
  $query12 = mysqli_query($con, $checkdp);
  $check12 = $query12->num_rows;

//echo $check12;
if ($fromAccount!='') {
  // code...

  if ($check12==0) {

    $sql20 = "INSERT INTO reportkbank(code, amount, fromacc, frombank, type, toacc, tobank, toname, fromname)
             
            VALUES('$code_dp', '$deposit',  '$fromAccount1',  '$fromAccountName',  '$transactionDescription2',  '$toacc',  '$toBankName',  '$toname',  '$fromName')";
    $result = mysqli_query($con, $sql20) or die ("Error in query: $sql " . mysqli_error());
  }

}elseif ($transactionDescription2=='โอนเงิน') {
    if ($check12==0) {

    $sql20 = "INSERT INTO reportkbank(code, amount, fromacc, frombank, type, toacc, tobank, toname, fromname)
             
            VALUES('$code_dp', '$deposit',  '$fromAccount1',  '$fromAccountName',  '$transactionDescription2',  '$toacc',  '$toBankName',  '$toname',  '$fromName')";
    $result = mysqli_query($con, $sql20) or die ("Error in query: $sql " . mysqli_error());
  }
}


}
