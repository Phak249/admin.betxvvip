const mysql = require('./config/mysql');
const app = require('./config/express')();
const { AutoCheckQRCode } = require('./app/controllers/backend.controller')
const port = 13000;
mysql.db(async function(db) {
    if (db) {
        app.listen(port);
        module.exports = app;
        // await AutoCheckQRCode();
        console.log('server-bakcend running at port ' + port);

    } else {
        logError.historyLogError(JSON.stringify(db));
        console.log('server-bakcend is error ');
    }
});