<?php include '../inc/header.php'; ?>
<?php include '../Command/body_aff_report.php'; ?>
<?php include '../inc/footer.php'; ?>