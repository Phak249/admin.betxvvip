
<?php
 require '../config.php';
require '../config/connectdb.php';
 require 'apiufa1062.php';
 require 'tmn_new.php';
 
 
$sql = "SELECT * FROM bank WHERE name_bank='ทรูวอเล็ต'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$number = $row['bankacc_bank'];
$password = $row['password_true'];
// $no_true = $row['no_true'];
// $otp_true = $row['otp_true'];

//echo $number;

$pin = $row['pin_bank'];
$tw = new iWallet($number,$password,$pin);
$test = $tw->GetBalance();
$credit_true = $test["data"]["current_balance"];
print_r($tw->GetBalance());
echo '<br>';

$sql8 = "UPDATE credit SET  
            credit_true='$credit_true'
            WHERE id=1";
$result9 = mysqli_query($con, $sql8) or die ("Error in query: $sql " . mysqli_error());

$transactions = $tw->GetTransaction();
//print_r($transactions);

$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);
$agent_user=$row['agent'];
$status_auto2 = $row['status_auto2'];

if ($status_auto2=='เปิด') {

if($transactions == null){ ///ถ้าไม่มีรายการ ให้ปิดการใช้งาน
exit;
}else{
	echo 'ดึงรายการสำเร็จ';
}
$sql = "SELECT * FROM `member`";
$con = $server->query($sql);
	
while($rs=$con->fetch_assoc() ){
	
	
foreach ($transactions["data"]["activities"] as $v) {

$date_time = $v["date_time"];
//echo $date_time;
$vowels = array("+", ",");
$balance = str_replace($vowels, "", $v["amount"]);
// echo $balance;
// echo '<br>';
$vowels2 = array("-", "+");
$phone_in = str_replace($vowels2, "", $v["transaction_reference_id"]);
$deposit = $balance;
//echo $phone_in;
if ($balance > 0) {
	
// echo $phone_in;
// echo '<br>';
 
$sql_check = "SELECT * FROM deposit WHERE date_check_true ='$date_time' and amount_dp ='$balance' AND confirm_dp='อนุมัติ' AND bankin_dp='ทรูวอเล็ต'";
$con_check = $server->query($sql_check);
$check = $con_check->num_rows;
// echo $check;
// echo '<br>';
// //echo $balance;

if($check == 0){	

$decription = $rs['phone_true']; //เชคเบอร์ว่าตรงกับ member มั้ย
// echo $rs['phone_true'];
// echo '<br>';





if ($phone_in == $decription) {
	 //echo $agent_user;
		

		$sql_check="SELECT * FROM deposit WHERE fromTrue='$phone_in' AND confirm_dp='รอดำเนินการ' ORDER BY id DESC LIMIT 1";
		$query = $server->query($sql_check);

		$row_pro = mysqli_fetch_assoc($query);
		$get_pro = $row_pro['promotion_dp'];
		$phone_dp = $row_pro['phone_dp'];
		$username = $row_pro['username_dp'];
	//echo $get_pro;
	$check = $query->num_rows;
		//echo $check;
	if ($check==1) {


		//echo 4444444444;
		$sql_promotion="SELECT * FROM promotion WHERE name_pro='$get_pro'";
		$result7 = $server->query( $sql_promotion);
		$row7 = mysqli_fetch_assoc($result7);
		$money = $row7['dp_pro'];
		$namepro= $row7['name_pro'];
		$bonusper_pro = $row7['bonusper_pro'];
		$dp_pro = $row7['dp_pro'];
		$turn = $row7['turn_pro'];
		$max_pro = $row7['max_pro'];
		

		//echo $max_pro;
function extract_int($str){
     preg_match('/[^0-9]*([0-9]+)[^0-9]*/', $str, $regs);
     return (intval($regs[1]));
}
$a=$turn;
$turnover1 = extract_int($a);

		$bonus_pro1 = $row7['bonus_pro'] + ($deposit * $bonusper_pro / 100);

		if ($bonus_pro1>$max_pro) {
			$bonus_pro=$max_pro;
		}else{
			$bonus_pro = $row7['bonus_pro'] + ($deposit * $bonusper_pro / 100);
		}



//echo $bonus_pro;
		if ($bonusper_pro!=0) {
			$turn_pro = ($deposit + $bonus_pro) * $turnover1;
		}else{
			$turn_pro = $turnover1;
		} 
//echo $turn_pro;
	
if ($get_pro==$namepro and $deposit>=$money) {
			$sum = $deposit + $bonus_pro;
		}else{
			$sum = $deposit;
		}



		$usernameufa = $agent_user.$username;
		$status= $api->add_credit($usernameufa,$sum); 
		$status = json_decode($status);
		$status = $status->status;

if ($status==200 and $get_pro==$namepro and $deposit>=$money) {
	$sql = "UPDATE deposit SET  
            confirm_dp='อนุมัติ' , 
            amount_dp='$deposit' ,
            bonus_dp='$bonus_pro' ,
            bankin_dp = 'ทรูวอเล็ต' ,
            date_check_true ='$date_time' ,
            
            turnover = '$turn_pro' ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
            $result = $server->query( $sql) or die ("Error in query: $sql " . mysqli_error());

            $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
			$result5 = $server->query( $sql5);
			$row5 = mysqli_fetch_assoc($result5);
			$key = $row5['linedeposit'];



            $sMessage = "ฝากทรูวอเล็ตออโต้ \nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone_dp."\nโปรโมชั่น ".$get_pro;
				$chOne = curl_init(); 
				curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				curl_setopt( $chOne, CURLOPT_POST, 1); 
				curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				$result = curl_exec( $chOne ); 
				if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
					$result_ = json_decode($result, true); } 
					curl_close( $chOne );

	}elseif($status==200){

		$sql = "UPDATE deposit SET  
            confirm_dp ='อนุมัติ' , 
            amount_dp ='$deposit' ,
            bonus_dp = 0 ,
            bankin_dp = 'ทรูวอเล็ต' ,
            date_check_true ='$date_time' ,
           
            promotion_dp = 'ไม่รับโบนัส' ,
            turnover = 0 ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
            $result = $server->query( $sql) or die ("Error in query: $sql " . mysqli_error());


            $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
			$result5 = $server->query( $sql5);
			$row5 = mysqli_fetch_assoc($result5);
			$key = $row5['linedeposit'];



            $sMessage = "ฝากทรูวอเล็ตออโต้ \nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone_dp."\n"."ไม่รับโบนัส";
				$chOne = curl_init(); 
				curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				curl_setopt( $chOne, CURLOPT_POST, 1); 
				curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				$result = curl_exec( $chOne ); 
				if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
					$result_ = json_decode($result, true); } 
					curl_close( $chOne ); 
	}
//echo $sum;
	
	}else{
//echo $phone_in;
		if ($phone_in!='') {
			
		
	$sql_topup = "SELECT * FROM member WHERE phone_true = '$phone_in'";
	$result7 =$server->query( $sql_topup);
	$row7 = mysqli_fetch_assoc($result7);
	$username = $row7['username_mb'];
	$id_mb = $row7['id_mb'];
	$fromTrue = $row7['	phone_true'];
	$phone_mb = $row7['phone_mb'];
	$username = $row7['username_mb'];
	$bank_mb = $row7['bank_mb'];
	$bankacc_mb = $row7['bankacc_mb'];
	$name_mb = $row7['name_mb'];
	$aff = $row7['aff'];
//echo $username;
	$usernameufa = $agent_user.$username;


		$status= $api->add_credit($usernameufa,$deposit); 
		$status = json_decode($status);
		$status = $status->status;
		if ($status==200){

    $sql = "INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, fromTrue, date_check_true, bankin_dp, fromAccount, turnover)
             VALUES('$id_mb', '$username', '$phone_mb', '$bank_mb', '$bankacc_mb','$name_mb', 'อนุมัติ', '$deposit', 'ไม่รับโบนัส', '$aff', '', '0', '$fromTrue', '$date_time', 'ทรูวอเล็ต', '$phone_in', 0)";

    $result = $server->query( $sql) or die ("Error in query: $sql " . mysqli_error());

            
            $sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
			$result5 = $server->query( $sql5);
			$row5 = mysqli_fetch_assoc($result5);
			$key = $row5['linedeposit'];



            $sMessage = "ฝากทรูวอเล็ตออโต้ \nจำนวนเงิน ".$deposit." บาท\nเบอร์ ".$phone_mb."\n"."ไม่รับโบนัส";
				$chOne = curl_init(); 
				curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				curl_setopt( $chOne, CURLOPT_POST, 1); 
				curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				$result = curl_exec( $chOne ); 
				if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
					$result_ = json_decode($result, true); } 
					curl_close( $chOne ); 
				}
			}
	}
	}
}

}
}
}
}else{ echo 'ระบบออโต้ปิด';}
?>