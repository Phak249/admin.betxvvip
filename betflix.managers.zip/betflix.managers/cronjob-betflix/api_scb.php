<?php
header("Content-Type: text/html; charset=utf-8");
error_reporting(0);

date_default_timezone_set("Asia/Bangkok");
$date_now=date("Y-m-d");
$startDate=date("Y-m-d");
$endDate=$date_now;
require '../config.php';
$sql = "SELECT * FROM bank WHERE name_bank='ธนาคารไทยพาณิชย์' AND status_bank='เปิด' ORDER BY id DESC LIMIT 1";
$result =$server->query( $sql);
$row = mysqli_fetch_assoc($result);
 
$GLOBALS["accountFrom"]=$row['bankacc_bank'];  //เลขบัญชีตัวเอง
$pin=$row['pin_bank'];
$deviceId=$row['device'];
                
$auths=file_get_contents("scb_cookie.txt");



function code($value){
  $value=trim($value);

  if ($value=="ธ.ไทยพาณิชย์") {
    return '014';
  }

  if ($value=="ธ.กรุงเทพ") {
    return '002';
  }

  if ($value=="ธ.กสิกรไทย") {
    return '004';
  }

  if ($value=="ธ.กรุงไทย") {
    return '006';
  }

  if ($value=="ธ.ทหารไทยธนชาติ") {
    return '011';
  }

  if ($value=="ธ.กรุงศรีอยุธยา") {
    return '025';
  }
  if ($value=="ธ.ออมสิน") {
    return '030';
  }

  if ($value=="ธ.ก.ส.") {
    return '034';
  }
  
  if ($value=="ธ.ซีไอเอ็มบีไทย") {
    return '022';
  }
  
  if ($value=="ธ.เกียรตินาคินภัทร") {
    return '033';
  }
  
  if ($value=="ธ.ทิสโก้") {
    return '067';
  }
  
  if ($value=="ธ.ยูโอบี") {
    return '024';
  }
  
  if ($value=="ธ.อิสลาม") {
    return '066';
  }
  
  if ($value=="ธ.ไอซีบีซี") {
    return '070';
  }
}

function login(){
  $scbversion = "Android/10;FastEasy/3.53.0/5618";
require '../config.php';
$sql = "SELECT * FROM bank WHERE name_bank='ธนาคารไทยพาณิชย์' AND status_bank='เปิด' ORDER BY id DESC LIMIT 1";
$result =$server->query( $sql);
$row = mysqli_fetch_assoc($result);

$GLOBALS["accountFrom"]=$row['bankacc_bank'];  //เลขบัญชีตัวเอง
$pin=$row['pin_bank'];
$deviceId=$row['device'];
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://fasteasy.scbeasy.com:8443/v3/login/preloadandresumecheck',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_HEADER=> 1,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{"deviceId":"'.$deviceId.'","jailbreak":"0","tilesVersion":"41","userMode":"INDIVIDUAL"}',
  CURLOPT_HTTPHEADER => array(
    'Accept-Language:      th',
    'scb-channel:  APP',
    'user-agent: '.$scbversion ,
    'Content-Type:  application/json; charset=UTF-8',
    'Hos:  fasteasy.scbeasy.com:8443',
    'Connection:  close',
  ),
));

$response = curl_exec($curl);
curl_close($curl);


preg_match_all('/(?<=Api-Auth: ).+/', $response, $Auth);
$Auth=$Auth[0][0];

if ($Auth=="") {
  echo "Auth error";
  exit();
}


$curl1 = curl_init();

curl_setopt_array($curl1, array(
  CURLOPT_URL => 'https://fasteasy.scbeasy.com/isprint/soap/preAuth',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{"loginModuleId":"PseudoFE"}',
  CURLOPT_HTTPHEADER => array(
    'Api-Auth: '.$Auth,
    'Content-Type: application/json',
  ),
));

$response1 = curl_exec($curl1);

curl_close($curl1);


$data = json_decode($response1,true);

$hashType=$data['e2ee']['pseudoOaepHashAlgo'];
$Sid=$data['e2ee']['pseudoSid'];
$ServerRandom=$data['e2ee']['pseudoRandom'];
$pubKey=$data['e2ee']['pseudoPubKey'];



$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://poollin.scbpay.ml/pin/encrypt", // hash pin 
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "Sid=".$Sid."&ServerRandom=".$ServerRandom."&pubKey=".$pubKey."&pin=".$pin."&hashType=".$hashType,
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);

curl_close($curl);




$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://fasteasy.scbeasy.com/v1/fasteasy-login',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_HEADER=> 1,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{"deviceId":"'.$deviceId.'","pseudoPin":"'.$response.'","pseudoSid":"'.$Sid.'"}',
  CURLOPT_HTTPHEADER => array(
     'Accept-Language: th',
                'scb-channel: app',
                'user-agent:  '.$scbversion ,
                'Content-Type: application/json; charset=UTF-8',
                'Api-Auth: ' . $Auth,
                'Host: fasteasy.scbeasy.com:8443',
                'Connection: Keep-Alive',
                'Accept-Encoding: gzip'
  ),
));

$response_auth = curl_exec($curl);
//return $response_auth;
curl_close($curl);
 


preg_match_all('/(?<=Api-Auth:).+/', $response_auth, $Auth_result);
$Auth1=$Auth_result[0][0];
$myfile = file_put_contents('scb_cookie.txt', $Auth1.PHP_EOL , LOCK_EX);
 
if ($Auth1=="") {
  echo "Auth error";
  exit();

}
 }
 
 


if(isset($_GET['balance'])) {
   
  // echo  trim($auths);
    // echo login();
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://fasteasy.scbeasy.com/v2/deposits/summary',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>' 
    {"depositList":[{"accountNo":"'.$GLOBALS["accountFrom"].'"}],"numberRecentTxn":2,"tilesVersion":"41"}',
    CURLOPT_HTTPHEADER => array(
      'Api-Auth:'.trim($auths) ,
      'Content-Type:  application/json;charset=UTF-8'
    ),
  ));
   
  $response = curl_exec($curl);

  curl_close($curl);



  $result=json_decode($response,true);


  $data = array ('result'=>$result['totalAvailableBalance']);
  echo json_encode($data);
  
  

}

      if(isset($_GET['transactions'])) {
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://fasteasy.scbeasy.com/v2/deposits/casa/transactions",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS =>"{\"accountNo\":\"".$GLOBALS["accountFrom"]."\",\"endDate\":\"".$endDate."\",\"pageNumber\":\"1\",\"pageSize\":50,\"productType\":\"2\",\"startDate\":\"".$startDate."\"}",
    CURLOPT_HTTPHEADER => array(
      'Api-Auth:'.trim($auths) ,
      'Accept-Language: th',
      'Content-Type: application/json; charset=UTF-8'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);
 

  $result=json_decode($response,true);

  $check=$result['status']['description'];
   $des=$result['status']['code'];
    if ($des=='1002') {
   return login();
   }

  if ($check=='ไม่สามารถทำรายการทางการเงินได้ในขณะนี้') {
    $data = array ('result'=>'ไม่สามารถทำรายการทางการเงินได้ในขณะนี้');
    echo json_encode($data);
   
  }else{
    $data = array ('result'=>$result['data']['txnList']);
    echo json_encode($data);
  }
  
   

}




?>