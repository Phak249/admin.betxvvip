<div id="alert_sidebar" class="alert-sidebar"></div>
	<!-- Required Js -->
    <script src="csswin/vendor-all.min.js.download"></script>
    <script src="csswin/bootstrap.min.js.download"></script>
    <script src="csswin/pcoded.min.js.download"></script>
    <!--<script src="assets_admin/default/js/menu-setting.min.js"></script>-->
    <!-- notification Js -->
    <script src="csswin/bootstrap-notify.min.js.download"></script>
    <!--<script src="assets_admin/default/js/pages/ac-notification.js"></script>-->
	<script src="https://unpkg.com/jquery@3.3.1/dist/jquery.min.js"></script>
    <script src="https://unpkg.com/bootstrap@4.1.0/dist/js/bootstrap.min.js"></script>
   
	<script src="csswin/jquery.dataTables.min.js.download"></script>
	<script src="csswin/dataTables.bootstrap4.min.js.download"></script>
	<script src="csswin/data-basic-custom.js.download"></script>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
	<script src="csswin/jquery.min.js.download"></script>
	<script src="csswin/PNotify.js.download"></script>
	<script src="csswin/PNotifyButtons.js.download"></script>
	<script src="csswin/PNotifyCallbacks.js.download"></script>
	<script src="csswin/PNotifyDesktop.js.download"></script>
	<script src="csswin/PNotifyConfirm.js.download"></script>
	<script src="csswin/notify-event.js.download"></script>
	<script src="csswin/jquery.dataTables.min.js.download"></script>
    <script src="csswin/dataTables.bootstrap.min.js.download"></script>
	<script src="csswin/dataTables.buttons.min.js.download"></script>
	<script src="csswin/buttons.flash.min.js.download"></script>
	<script src="csswin/jszip.min.js.download"></script>
	<script src="csswin/pdfmake.min.js.download"></script>
	<script src="csswin/vfs_fonts.js.download"></script>
	<script src="csswin/buttons.html5.min.js.download"></script>
	<script src="csswin/buttons.print.min.js.download"></script>
	
	
	<!-- <script>
	$(function () {
	    $('#example1').DataTable()
	    $('#example2').DataTable({
	      'paging'      : true,
	      'lengthChange': false,
	      'searching'   : false,
	      'ordering'    : true,
	      'info'        : true,
	      'autoWidth'   : false
	    })
	  })
	</script> -->
	<script>
	initSample();
</script>
	</body>
    </html>