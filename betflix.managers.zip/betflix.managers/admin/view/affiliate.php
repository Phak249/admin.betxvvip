<?php include '../inc/header.php'; ?>
<?php include '../Command/body_affiliate.php'; ?>
<?php include '../inc/footer.php'; ?>