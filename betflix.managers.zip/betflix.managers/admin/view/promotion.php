<?php include '../inc/header.php'; ?>
<?php include '../Command/body_promotion.php'; ?>
<?php include '../inc/footer.php'; ?>