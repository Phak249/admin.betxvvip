<?php
error_reporting(0);
require '../config/connectdb.php';
require 'tmn_new.php';


$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result5 = mysqli_query($con, $sql5);
$row5 = mysqli_fetch_assoc($result5);
$key = $row5['linewithdraw'];

$sql = "SELECT * FROM bank WHERE name_bank='ทรูวอเล็ต'";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$number = $row['bankacc_bank'];
$password = $row['password_true'];
$pin = $row['pin_bank'];

$tw = new iWallet($number,$password,$pin);




$bank_number=$_POST['accountTo'];
$phone=$_POST['phone'];
$amount=$_POST['amount']; 
$key_input=$_POST['key_input'];
$add_wd=$_POST['add_wd'];
//echo $add_wd;

if ($key_input=='555555' AND $add_wd!='') {


	$withdraw2 = $tw->P2p($bank_number, $amount);
	$status2 = $withdraw2["data"]["transfer_status"];
//echo $status;
	if ($status2=='PROCESSING') {
		//require '../config/connectdb.php';
		

			$sMessage = "ถอนมือทรูวอเล็ตสำเร็จ \nจำนวนเงิน ".$amount." บาท\nเบอร์ ".$bank_number." \nผู้ทำรายการ ".$add_wd;
			 $chOne = curl_init();
				        curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
				        curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
				        curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
				        curl_setopt( $chOne, CURLOPT_POST, 1); 
				        curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
				        $headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$key.'', );
				        curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
				        curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
				        $result = curl_exec( $chOne ); 
				        if(curl_error($chOne)) {echo 'error:' . curl_error($chOne); }else { 
				          $result_ = json_decode($result, true); } 
				          curl_close( $chOne );


	header("Content-Type: text/html; charset=utf-8");
	echo "<script>";
    echo "alert('โอนเงินสำเร็จ');";
    echo "window.location.href='javascript:history.back(1)'; ";
    echo "</script>";
		
}else{
	header("Content-Type: text/html; charset=utf-8");
	echo "<script>";
    echo "alert('โอนไม่สำเร็จ !!!!!!!');";
    echo "window.location.href='javascript:history.back(1)'; ";
    echo "</script>";
}
}else{
	header("Content-Type: text/html; charset=utf-8");
	echo "<script>";
    echo "alert('รหัสลับไม่ถูกต้อง !!!!!!!');";
    echo "window.location.href='javascript:history.back(1)'; ";
    echo "</script>";

}		

?>