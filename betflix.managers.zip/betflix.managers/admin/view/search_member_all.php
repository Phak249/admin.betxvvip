<?php include '../inc/header.php'; ?>
<?php include '../Command/body_search_member_all.php'; ?>
<?php include '../inc/footer.php'; ?>