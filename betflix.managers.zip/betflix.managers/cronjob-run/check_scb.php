<?php
 //error_reporting(0);

require '../config/connectdb.php';
require 'apiufa1062.php';




$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$agent_user=$row['agent'];
$key = $row['linedeposit'];
$path='https://'.$row['link_web']."/";
$status_auto2 = $row['status_auto2'];
//echo $path;
if ($status_auto2=='เปิด') {
	

$sql_scb = "SELECT * FROM bank WHERE name_bank='ธนาคารไทยพาณิชย์' ORDER BY id DESC LIMIT 1";
$result_scb = mysqli_query($con, $sql_scb);
$row_scb = mysqli_fetch_assoc($result_scb);
$status_scb=$row_scb['status_bank'];
//echo $status_scb;

echo "scb ".$status_scb;
print"\n";
print"<br>";
date_default_timezone_set("Asia/Bangkok");
$date_now=date("Y-m-d");


 
$curl = curl_init();
curl_setopt_array($curl, array(
	CURLOPT_URL =>  $path."cronjob-run/api_scb.php?transactions",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
));

$transactions = curl_exec($curl);
curl_close($curl);
 
$result_transactions = json_decode($transactions,true);
 
$transactions_result=$result_transactions['result'];

//echo $transactions_result;

$curl = curl_init();
curl_setopt_array($curl, array(
	CURLOPT_URL => $path."cronjob-run/api_scb.php?balance",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
));

$response = curl_exec($curl);

  curl_close($curl);



$result=json_decode($response,true);
$data = array ('result'=>$result['result']);

$credit1 = $result['result'];

echo $credit;
echo '<br>';
echo $credit1;


if ($credit!='') {
	
$sql8 = "UPDATE credit SET  
            credit_ufa='$credit' , 
            credit_scb='$credit1'
            WHERE id=1";
$result9 = mysqli_query($con, $sql8) or die ("Error in query: $sql " . mysqli_error());
}

	if ($status_scb=='เปิด') {
		

foreach ($transactions_result as  $value) {
$txnCode=$value['txnCode']['description']; //รายการ
$txnDateTime=$value['txnDateTime']; //เวลา
$deposit=$value['txnAmount']; //ยอดเงิน
$txnRemark=$value['txnRemark']; //เลขบัญชี
$name=$value['txnRemark']; //ชื่อ
//echo $txnCode;
//echo $deposit;
$turn2=$deposit*2;
preg_match('/SCB/', $txnRemark, $output_array);
$check=$output_array[0];
$check_bank=$output_array[0];
if ($check=="SCB") {
	preg_match_all('/(?<=x)(.*?)(?= )/', $txnRemark, $output_array);
	$fromAccount=$output_array[0][0];
	$naem_cut=explode(" ",$name);
	$name='ไทยพาณิชย์';
	$namescb=$naem_cut[4];


}else{
	preg_match_all('/(?<=X).+/', $txnRemark, $output_array);
	$fromAccount=$output_array[0][0];
	preg_match('/.(.*?)(?= )/', $name, $output_array);
	$name=$output_array[0];


}
// echo $name;
// echo $time_check;


preg_match('/(.*?)(?=T)/', $txnDateTime, $output_array);
$date=date_create($output_array[0]);
$date_check=date_format($date,"Y-m-d");

preg_match('/(?<=T).(.*?)(?=\+)/', $txnDateTime, $output_array);
$time_check=$output_array[0];

// echo '<br>';
//echo $txnCode;
// echo '<br>';
// echo $txnRemark;
// echo '<br>';
// echo $deposit;
// echo '<br>';
// echo $date_check;
// echo $time_check;
// echo '<br>';

	$checkdp = "SELECT id FROM reportscb WHERE date_check='$date_check' AND time_check='$time_check'";
  $query12 = mysqli_query($con, $checkdp);
  $check12 = $query12->num_rows;



  if ($check12==0) {

    $sql20 = "INSERT INTO reportscb(type, amount, details, date_check, time_check, bank_acc)
             
            VALUES('$txnCode', '$deposit',  '$txnRemark',  '$date_check',  '$time_check', '$fromAccount')";
    $result = mysqli_query($con, $sql20) or die ("Error in query: $sql " . mysqli_error());
  }


}
}
}



