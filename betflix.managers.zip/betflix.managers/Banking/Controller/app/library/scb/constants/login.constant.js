const errorMsgScb = {
    'code_1060':{
        status: 400,
        statusCode: 1060,
        statusText: 'api auth faild',
        description: null
    }
}

module.exports = errorMsgScb