
<?php
//error_reporting(0);

require '../connectdb.php';
require 'api_betflix2.php';




$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$agent_user = $row['agent'];
$key = $row['linedeposit'];
$path = 'https://' . $row['link_web'] . "/";
$status_auto2 = $row['status_auto2'];
//echo $path;
if ($status_auto2 == 'เปิด') {


	$sql_scb = "SELECT * FROM bank WHERE name_bank='ธนาคารไทยพาณิชย์' ORDER BY id DESC LIMIT 1";
	$result_scb = mysqli_query($con, $sql_scb);
	$row_scb = mysqli_fetch_assoc($result_scb);
	$status_scb = $row_scb['status_bank'];
	//echo $status_scb;

	echo "scb " . $status_scb;
	print "\n";
	print "<br>";
	date_default_timezone_set("Asia/Bangkok");
	$date_now = date("Y-m-d");



	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_URL =>  $path . "cronjob-betflix/api_scb.php?transactions",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
	));

	$transactions = curl_exec($curl);
	curl_close($curl);

	$result_transactions = json_decode($transactions, true);

	$transactions_result = $result_transactions['result'];

	//echo $transactions_result;

	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_URL => $path . "cronjob-betflix/api_scb.php?balance",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
	));

	$response = curl_exec($curl);

	curl_close($curl);



	$result = json_decode($response, true);
	$data = array('result' => $result['result']);

	$credit1 = $result['result'];



	if ($credit1 != '') {

		$sql8 = "UPDATE credit SET  
           credit_scb='$credit1',
           credit_ufa='$Balance33'
            WHERE id=1";
		$result9 = mysqli_query($con, $sql8) or die("Error in query: $sql " . mysqli_error());
	}

	if ($status_scb == 'เปิด') {


		foreach ($transactions_result as  $value) {
			$txnCode = $value['txnCode']['description']; //รายการ
			$txnDateTime = $value['txnDateTime']; //เวลา
			$deposit = $value['txnAmount']; //ยอดเงิน
			$txnRemark = $value['txnRemark']; //เลขบัญชี
			$name = $value['txnRemark']; //ชื่อ
			//echo $txnCode;
			//echo $deposit;

			preg_match('/SCB/', $txnRemark, $output_array);
			$check = $output_array[0];
			$check_bank = $output_array[0];
			if ($check == "SCB") {
				preg_match_all('/(?<=x)(.*?)(?= )/', $txnRemark, $output_array);
				$fromAccount = $output_array[0][0];
				$naem_cut = explode(" ", $name);
				$name = 'ไทยพาณิชย์';
				$namescb = $naem_cut[4];
				$turn2 = $deposit * 2;
			} else {
				preg_match_all('/(?<=X).+/', $txnRemark, $output_array);
				$fromAccount = $output_array[0][0];
				preg_match('/.(.*?)(?= )/', $name, $output_array);
				$name = $output_array[0];
			}
			// echo $name;
			// echo $deposit;


			preg_match('/(.*?)(?=T)/', $txnDateTime, $output_array);
			$date = date_create($output_array[0]);
			$date_check = date_format($date, "Y-m-d");

			preg_match('/(?<=T).(.*?)(?=\+)/', $txnDateTime, $output_array);
			$time_check = $output_array[0];

			$checkdp = "SELECT id FROM reportscb WHERE date_check='$date_check' AND time_check='$time_check'";
			$query12 = mysqli_query($con, $checkdp);
			$check12 = $query12->num_rows;



			if ($check12 == 0) {

				$sql20 = "INSERT INTO reportscb(type, amount, details, date_check, time_check)
             
            VALUES('$txnCode', '$deposit',  '$txnRemark',  '$date_check',  '$time_check')";
				$result = mysqli_query($con, $sql20) or die("Error in query: $sql " . mysqli_error());
			}


			//echo $fromAccount;
			if ($txnCode == "ฝากเงิน") {

				$sql_checkdp = "SELECT * FROM deposit WHERE date_check='$date_check' AND time_check='$time_check' AND fromAccount = '$fromAccount'";
				$query2 = mysqli_query($con, $sql_checkdp);
				$check2 = $query2->num_rows;
				// echo $time_check;
				// echo '<br>';
				// echo $check2;
				// echo '<br>';
				// echo $deposit;
				if ($check2 == 0) {


					$sql_check = "SELECT * FROM deposit WHERE bankacc_dp LIKE '%$fromAccount%' AND confirm_dp='รอดำเนินการ' ORDER BY id DESC LIMIT 1";

					$query = mysqli_query($con, $sql_check);

					$row_pro = mysqli_fetch_assoc($query);
					$get_pro = $row_pro['promotion_dp'];
					$username = $row_pro['username_dp'];
					$phone_dp = $row_pro['phone_dp'];
					$check = $query->num_rows;
					//echo $check;
					if ($check == 1) {
						$sql_promotion = "SELECT * FROM promotion WHERE name_pro='$get_pro'";
						$result7 = mysqli_query($con, $sql_promotion);
						$row7 = mysqli_fetch_assoc($result7);
						$money = $row7['dp_pro'];
						$namepro = $row7['name_pro'];
						$bonusper_pro = $row7['bonusper_pro'];
						$dp_pro = $row7['dp_pro'];
						$turn = $row7['turn_pro'];
						$max_pro = $row7['max_pro'];
						//echo $max_pro;
						function extract_int($str)
						{
							preg_match('/[^0-9]*([0-9]+)[^0-9]*/', $str, $regs);
							return (intval($regs[1]));
						}
						$a = $turn;
						$turnover1 = extract_int($a);

						$bonus_pro1 = $row7['bonus_pro'] + ($deposit * $bonusper_pro / 100);

						if ($bonus_pro1 > $max_pro) {
							$bonus_pro = $max_pro;
						} else {
							$bonus_pro = $row7['bonus_pro'] + ($deposit * $bonusper_pro / 100);
						}



						//echo $bonus_pro;
						if ($bonusper_pro != 0) {
							$turn_pro = ($deposit + $bonus_pro) * $turnover1;
						} else {
							$turn_pro = $turnover1;
						}
						//echo $turn_pro;

						if ($get_pro == $namepro and $deposit >= $money) {
							$sum = $deposit + $bonus_pro;
						} else {
							$sum = $deposit;
						}

						//echo $sum;
						$usernameufa = $agent_user . $username;
						//echo $usernameufa;
						$status = deposit($usernameufa, $sum);
						$status = json_decode($status);
						$status = $status->status;

						if ($status == 'success' and $get_pro == $namepro and $deposit >= $money) {
							$sql7 = "UPDATE deposit SET  
            confirm_dp='อนุมัติ' , 
            amount_dp='$deposit' ,
            bonus_dp='$bonus_pro' ,
            bankin_dp = 'ธนาคารไทยพาณิชย์' ,
            date_check ='$date_check' ,
            time_check = '$time_check' ,
            turnover = '$turn_pro' ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
							$result7 = mysqli_query($con, $sql7) or die("Error in query: $sql " . mysqli_error());

							if ($result7 == true) {

								$sql5 = "SELECT * FROM setting";
								$result5 = mysqli_query($con, $sql5);
								$row5 = mysqli_fetch_assoc($result5);
								$key = $row5['linedeposit'];



								$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_dp . "\nโปรโมชั่น " . $get_pro;
								$chOne = curl_init();
								curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
								curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
								curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
								curl_setopt($chOne, CURLOPT_POST, 1);
								curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
								$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
								curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
								curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
								$result = curl_exec($chOne);
								if (curl_error($chOne)) {
									echo 'error:' . curl_error($chOne);
								} else {
									$result_ = json_decode($result, true);
								}
								curl_close($chOne);
							}
						} elseif ($status == 'success') {

							$sql = "UPDATE deposit SET  
            confirm_dp ='อนุมัติ' , 
            amount_dp ='$deposit' ,
            bonus_dp = 0 ,
            bankin_dp = 'ธนาคารไทยพาณิชย์' ,
            date_check ='$date_check' ,
            time_check = '$time_check' ,
            promotion_dp = 'ไม่รับโบนัส' ,
            turnover = '$turn2' ,
            fromAccount = '$fromAccount'
            WHERE username_dp='$username' ORDER BY id DESC LIMIT 1 ";
							$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error());

							$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
							$result5 = mysqli_query($con, $sql5);
							$row5 = mysqli_fetch_assoc($result5);
							$key = $row5['linedeposit'];



							$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_dp . "\n" . "ไม่รับโบนัส";
							$chOne = curl_init();
							curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
							curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
							curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
							curl_setopt($chOne, CURLOPT_POST, 1);
							curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
							$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
							curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
							curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
							$result = curl_exec($chOne);
							if (curl_error($chOne)) {
								echo 'error:' . curl_error($chOne);
							} else {
								$result_ = json_decode($result, true);
							}
							curl_close($chOne);
						}
						//echo $sum;

					} else {

						if ($name == 'ไทยพาณิชย์') {

							//echo $name;

							$sql_topup = "SELECT * FROM member WHERE bankacc_mb LIKE '%$fromAccount%' AND bank_mb ='ธ.ไทยพาณิชย์'";
							$result7 = mysqli_query($con, $sql_topup);
							while ($row7 = mysqli_fetch_array($result7)) {
								$username = $row7['username_mb'];
								$id_mb = $row7['id_mb'];
								$fromTrue = $row7['	phone_true'];
								$phone_mb = $row7['phone_mb'];
								$bank_mb = $row7['bank_mb'];
								$bankacc_mb2 = $row7['bankacc_mb'];
								$name_mb = $row7['name_mb'];
								$aff = $row7['aff'];
								//echo $username;
								$usernameufa = $agent_user . $username;

								$bankacc_mb = substr($bankacc_mb2, 6);
								// echo $bankacc_mb;
								// echo '<br>';

								// echo $fromAccount;
								// echo '<br>';

								if ($fromAccount == $bankacc_mb) {
									//echo $name_mb;
									//echo $usernameufa;
									$status = deposit($usernameufa, $deposit);
									$status = json_decode($status);
									$status = $status->status;
									if ($status == 'success') {

										$sql = "INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, fromTrue, date_check, time_check, bankin_dp, fromAccount, turnover)
             VALUES('$id_mb', '$username', '$phone_mb', '$bank_mb', '$bankacc_mb','$name_mb', 'อนุมัติ', '$deposit', 'ไม่รับโบนัส', '$aff', '', '0', '$fromTrue', '$date_check', '$time_check', 'ธนาคารไทยพาณิชย์', '$fromAccount', 0)";

										$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error());


										$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
										$result5 = mysqli_query($con, $sql5);
										$row5 = mysqli_fetch_assoc($result5);
										$key = $row5['linedeposit'];



										$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_mb . "\n" . "ไม่รับโบนัส";
										$chOne = curl_init();
										curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
										curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
										curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
										curl_setopt($chOne, CURLOPT_POST, 1);
										curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
										$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
										curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
										$result = curl_exec($chOne);
										if (curl_error($chOne)) {
											echo 'error:' . curl_error($chOne);
										} else {
											$result_ = json_decode($result, true);
										}
										curl_close($chOne);
									}
								}
							}
						} else {
							$sql_topup = "SELECT * FROM member WHERE bankacc_mb LIKE '%$fromAccount%'";
							$result7 = mysqli_query($con, $sql_topup);
							while ($row7 = mysqli_fetch_array($result7)) {
								$username = $row7['username_mb'];
								$id_mb = $row7['id_mb'];
								$fromTrue = $row7['	phone_true'];
								$phone_mb = $row7['phone_mb'];
								$bank_mb = $row7['bank_mb'];
								$bankacc_mb2 = $row7['bankacc_mb'];
								$name_mb = $row7['name_mb'];
								$aff = $row7['aff'];

								$usernameufa = $agent_user . $username;

								//echo $name;
								if ($name == 'ออมสิน') {
									$bankacc_mb = substr($bankacc_mb2, 6);
								} elseif ($name == 'ธกส.') {
									$bankacc_mb = substr($bankacc_mb2, 6);
								} else {
									$bankacc_mb = substr($bankacc_mb2, 4);
								}
								// echo $bankacc_mb;
								// echo '<br>';

								// echo $fromAccount;
								// echo '<br>';

								if ($fromAccount == $bankacc_mb) {
									//echo $username;



									$status = deposit($usernameufa, $deposit);
									$status = json_decode($status);
									$status = $status->status;
									if ($status == 'success') {

										$sql = "INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, fromTrue, date_check, time_check, bankin_dp, fromAccount, turnover)
             VALUES('$id_mb', '$username', '$phone_mb', '$bank_mb', '$bankacc_mb','$name_mb', 'อนุมัติ', '$deposit', 'ไม่รับโบนัส', '$aff', '', '0', '$fromTrue', '$date_check', '$time_check', 'ธนาคารไทยพาณิชย์', '$fromAccount', 0)";

										$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error());


										$sql5 = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
										$result5 = mysqli_query($con, $sql5);
										$row5 = mysqli_fetch_assoc($result5);
										$key = $row5['linedeposit'];



										$sMessage = "ฝากเครดิตออโต้ SCB \nจำนวนเงิน " . $deposit . " บาท\nเบอร์ " . $phone_mb . "\n" . "ไม่รับโบนัส";
										$chOne = curl_init();
										curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
										curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
										curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
										curl_setopt($chOne, CURLOPT_POST, 1);
										curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
										$headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key . '',);
										curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
										curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
										$result = curl_exec($chOne);
										if (curl_error($chOne)) {
											echo 'error:' . curl_error($chOne);
										} else {
											$result_ = json_decode($result, true);
										}
										curl_close($chOne);
									}
								}
							}
						}
					}
				} else {
					echo "no update";
					print "<br>";
				}
			}
		}
	}
} else {
	echo 'ระบบออโต้ปิด';
}
