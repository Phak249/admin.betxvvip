<?php include '../inc/header.php'; ?>
<?php include '../Command/body_manual.php'; ?>
<?php include '../inc/footer.php'; ?>
