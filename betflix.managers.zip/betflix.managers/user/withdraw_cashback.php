<?php
include('../config/connectdb.php');  // Connection to the database

// Get the latest settings from the database
$sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_array($result);

extract($row);
$key = $linewithdraw;

// Get form data
$id_wd = $_POST["id_wd"];
$username_wd = $_POST["username_wd"];
$amount_cashback = $_POST["amount_cashback"];
$phone_wd = $_POST["phone_wd"];
$bank_wd = $_POST["bank_wd"];
$bankacc_wd = $_POST["bankacc_wd"];
$name_wd = $_POST["name_wd"];
$confirm_wd = $_POST["confirm_wd"];

// Calculate total deposit for the previous day
$today_dp = date('Y-m-d', strtotime('-1 day'));
$querydp2 = "SELECT SUM(amount_dp) AS total FROM deposit WHERE confirm_dp = 'อนุมัติ' AND promotion_dp = 'ไม่รับโบนัส' AND phone_dp = ? AND date_dp LIKE ?";
$stmt_dp2 = mysqli_prepare($con, $querydp2);
$today_dp_like = "%$today_dp%";
mysqli_stmt_bind_param($stmt_dp2, 'ss', $phone_wd, $today_dp_like);
mysqli_stmt_execute($stmt_dp2);
$resultdp2 = mysqli_stmt_get_result($stmt_dp2);
$row = mysqli_fetch_assoc($resultdp2);

$today_wd = date('Y-m-d', strtotime('-1 day'));
$querywd2 = "SELECT SUM(amount_wd) AS total FROM withdraw WHERE confirm_wd = 'อนุมัติ' AND phone_wd = ? AND date_wd LIKE ?";
$stmt_wd2 = mysqli_prepare($con, $querywd2);
mysqli_stmt_bind_param($stmt_wd2, 'ss', $phone_wd, $today_dp_like);
mysqli_stmt_execute($stmt_wd2);
$resultwd2 = mysqli_stmt_get_result($stmt_wd2);
$row2 = mysqli_fetch_assoc($resultwd2);

$total = $row['total'] - $row2['total'];
$total1 = $total * $cashback / 100;

include('../cronjob-run/apiufa1062.php');

if ($total1 <= 0) {
    echo "<script>";
    echo "window.location = 'index.php?do=21'; ";
    echo "</script>";
} else {
    date_default_timezone_set('asia/bangkok');
    $month_wd = date('Y-m-d');
    $check = "SELECT phone_wd FROM withdraw WHERE phone_wd = ? AND amount_cashback != '' AND date_wd LIKE ?";
    $stmt_check = mysqli_prepare($con, $check);
    mysqli_stmt_bind_param($stmt_check, 'ss', $phone_wd, $month_wd);
    mysqli_stmt_execute($stmt_check);
    $result1 = mysqli_stmt_get_result($stmt_check);
    $num = mysqli_num_rows($result1);

    if ($num > 0) {
        echo "<script>";
        echo "window.location = 'index.php?do=22'; ";
        echo "</script>";
    } else {
        // Insert withdrawal record
        $sql9 = "INSERT INTO withdraw (id_wd, username_wd, phone_wd, bank_wd, bankacc_wd, name_wd, confirm_wd, amount_cashback, bankout_wd) VALUES (?, ?, ?, ?, ?, ?, 'อนุมัติ', ?, 'คืนยอดเสีย')";
        $stmt9 = mysqli_prepare($con, $sql9);
        mysqli_stmt_bind_param($stmt9, 'ssssssds', $id_wd, $username_wd, $phone_wd, $bank_wd, $bankacc_wd, $name_wd, $total1);
        $result9 = mysqli_stmt_execute($stmt9);
    }
}

if ($result9) {
    $usernameufa = $agent . $username_wd;
    $status = $api->add_credit($usernameufa, $total1);
    $status = json_decode($status);
    $status = $status->status;

    $sMessage = "รับยอดเสีย \nจำนวนเงิน " . $total1 . " บาท\nเบอร์ " . $phone_wd . " \nชื่อ " . $name_wd;
    $chOne = curl_init();
    curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify");
    curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($chOne, CURLOPT_POST, 1);
    curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . $sMessage);
    $headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer ' . $key);
    curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($chOne);
    if (curl_error($chOne)) {
        echo 'error:' . curl_error($chOne);
    } else {
        $result_ = json_decode($result, true);
    }
    curl_close($chOne);
}

// Close the database connection
mysqli_close($con);

// Redirect to the appropriate page based on the result
if ($result9) {
    header("Content-Type: text/html; charset=utf-8");
    echo "<script type='text/javascript'>";
    echo "window.location = 'index.php?do=23'; ";
    echo "</script>";
} else {
    header("Content-Type: text/html; charset=utf-8");
    echo "<script type='text/javascript'>";
    echo "alert('Error back to withdraw again');";
    echo "</script>";
}
?>
