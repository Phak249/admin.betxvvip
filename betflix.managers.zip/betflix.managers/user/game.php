<?php
session_start();

if (isset($_SESSION['phone_mb'])) {
    require '../config/connectdb.php';
    include '../class/betflix.php';

    $api = new Betflix();

    // ดึงการตั้งค่าจากฐานข้อมูล
    $sql = "SELECT * FROM setting ORDER BY id DESC LIMIT 1";
    $res = $con->query($sql);
    if ($res) {
        $row = $res->fetch_assoc();
        $agent = isset($row['agent']) ? $row['agent'] : '';  // ตรวจสอบว่าค่ามีอยู่ใน array หรือไม่
        $usernameufa = $agent . $_SESSION['username_mb'];

        // ทำการเข้าสู่ระบบผ่าน API
        $data = $api->login($usernameufa);

        // ตรวจสอบผลการเข้าสู่ระบบ
        if (!$data->error_code) {
            $token = $data->data->login_token;
            $rand = rand(10, 15);  // สุ่มเลขสำหรับ URL
            header('Location: https://ismgaming' . $rand . '.com/login/apilogin/' . $token);
            exit();  // ใช้ exit เพื่อหยุดการทำงานหลังจาก redirect
        } else {
            // หากมีข้อผิดพลาดในการเข้าสู่ระบบ, เปลี่ยนเส้นทางไปยังหน้าหลัก
            header('Location: user/index.php');
            exit();
        }
    } else {
        // หากไม่สามารถดึงข้อมูลจากฐานข้อมูลได้, แจ้งข้อผิดพลาด
        echo "Error retrieving settings from database.";
        exit();
    }
} else {
    // หากไม่มีการตั้งค่า session 'phone_mb', เปลี่ยนเส้นทางไปหน้า login
    header('Location: login.php');
    exit();
}
