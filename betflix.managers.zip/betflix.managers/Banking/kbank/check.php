<?php
require '../config.php';
$sql = "SELECT * FROM bank WHERE name_bank='ธนาคารกสิกรไทย'";
$result = $server->query($sql);
$row = mysqli_fetch_assoc($result);



require_once __DIR__ . '/kplus.Class.php';


$api2 = new Kplus($endpoint);
//$json = json_encode($api->getBalance(),JSON_UNESCAPED_UNICODE);
$json = json_encode($api2->getTransactions());

//$json = json_encode($api->getTransactionDetail('001_20220409_0142258A3B1144A90D2,A,CR,N'));
echo( $json);
// print_r($api->transferVerify('004', '4220336001', '200'));
//echo json_encode($api->transferConfrim('InquireTransferORFT09699423161b9320b4'));




// echo $balanceKbank;